<?php
use Core\FH;
?>
<?php $this->setSiteTitle('Login | '. SITE_TITLE); ?>
<?php $this->start('body'); ?>
<div class="login-box panel panel-body panel-default" style="padding: 2em">
    <br />
  <div class="login-box-body">
    <p class="text-center"><img src="<?=PROOT?>assets/img/u3.png" class="img-thumbnil" width="200" alt=""></p>

    <form action="<?=PROOT?>register/login" method="post">
    <br />
    <?= FH::csrfInput() ?>
    <?= FH::displayErrors($this->displayErrors) ?>
    <?= FH::inputBlock('text','Utilizador','user_name',$this->login->user_name,['class'=>'form-control', 'placeholder'=>''],['class'=>'form-group has-feedback"'],$this->displayErrors) ?>
    <?= FH::inputBlock('password','Senha','user_password',$this->login->user_password,['class'=>'form-control', 'placeholder'=>''],['class'=>'form-group has-feedback"'],$this->displayErrors) ?>
      <div class="row">
        <?= FH::checkboxBlock('Lembrar-me','remember_me',$this->login->getRememberMeChecked(),[],['class'=>'col-xs-8'],$this->displayErrors) ?>
        <!-- /.col -->
        <div class="col-xs-4">
          <br>
          <?= FH::submitTag('Entrar',['class'=>'btn btn-danger btn-block btn-flat']) ?>
        </div>
        <!-- /.col -->
      </div>
    </form>
  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->
<?php $this->end(); ?>
