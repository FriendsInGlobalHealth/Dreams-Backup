<?php
use Core\FH;
?>
<?php $this->setSiteTitle('Login | '. SITE_TITLE); ?>
<?php $this->start('body'); ?>
<div class="login-box panel panel-body panel-default" style="padding: 2em">
    <br />
  <div class="login-box-body">
    <p class="text-center"><img src="<?=PROOT?>assets/img/u3.png" class="img-thumbnil" width="200" alt=""></p>

    <form action="<?=PROOT?>register/register" method="post">
    <h3 class="text-center">Registrar!</h3><hr>
    <br />
    <?= FH::csrfInput() ?>
    <?= FH::displayErrors($this->displayErrors) ?>
      <?= FH::csrfInput() ?>
      <?= FH::inputBlock('text','Nome','fname',$this->newUser->fname,['class'=>'form-control input-sm'],['class'=>'form-group'],$this->displayErrors) ?>
      <?= FH::inputBlock('text','Apelido','lname',$this->newUser->lname,['class'=>'form-control input-sm'],['class'=>'form-group'],$this->displayErrors) ?>
      <?= FH::inputBlock('text','Email','user_email',$this->newUser->user_email,['class'=>'form-control input-sm'],['class'=>'form-group'],$this->displayErrors) ?>
      <?= FH::inputBlock('text','Username','user_name',$this->newUser->user_name,['class'=>'form-control input-sm'],['class'=>'form-group'],$this->displayErrors) ?>
      <?= FH::inputBlock('password','Password','user_password',$this->newUser->user_password,['class'=>'form-control input-sm'],['class'=>'form-group'],$this->displayErrors) ?>
      <?= FH::inputBlock('password','Confirme Password','confirm',$this->newUser->confirm,['class'=>'form-control input-sm'],['class'=>'form-group'],$this->displayErrors) ?>
      <div class="row">
        <div class="col-xs-8">Tenho conta? <a href="<?=PROOT?>register/login">Log In</a></div>
        <div class="col-xs-4">
          <?= FH::submitTag('Registrar',['class'=>'btn btn-danger btn-flat']) ?>
        </div>
      </div>
    </div>
    </form>
  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->
<?php $this->end(); ?>
