<?php
  use Core\Router;
  use Core\H;
  use App\Models\Users;
  use Core\Session;
  $menu = Router::getMenu('menu_acl');
  $userMenu = Router::getMenu('user_menu');
?>
<header class="main-header">
    <!-- Logo -->
    <a href="<?=PROOT?>" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>IMD</b></span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>IMD</b>MISAU - 2019</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">

      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>

      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Messages: style can be found in dropdown.less-->
          <li class="dropdown messages-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-envelope-o"></i>
              <span class="label label-success">4</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">Tem 4 menssagens</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <?php for ($i=1; $i < 5; $i++) { ?>

                  <li><!-- start message -->
                    <a href="#">
                      <div class="pull-left">
                        <img src="<?=PROOT?>assets/img/logo_vbg.png" class="img-circle" alt="User Image">
                      </div>
                      <h4>
                        Equipe de Suporte
                        <small><i class="fa fa-clock-o"></i> <?= rand(10,25); ?> mins</small>
                      </h4>
                      <p><?= $i.'º Problema Reportado';?></p>
                    </a>
                  </li>
                  <?php } ?>
                </ul>
              </li>
              <li class="footer"><a href="#">Ver todas >> </a></li>
            </ul>
          </li>
          <!-- Notifications: style can be found in dropdown.less -->
          <li class="dropdown notifications-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-bell-o"></i>
              <span class="label label-warning">10</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">Tem 10 notificações</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <li>
                    <a href="#">
                      <i class="fa fa-users text-aqua"></i> 5 novos membros avaliados hoje
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <i class="fa fa-warning text-yellow"></i> Identificação Precoce de Vítimas de Violência Baseada no Gênero
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <i class="fa fa-users text-red"></i> 5 novos membros
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <i class="fa fa-shopping-cart text-green"></i> 25 referências a Unidade Policila9
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <i class="fa fa-user text-red"></i> You changed your username
                    </a>
                  </li>
                </ul>
              </li>
              <li class="footer"><a href="#">View all</a></li>
            </ul>
          </li>
          <!-- Tasks: style can be found in dropdown.less -->
          <li class="dropdown tasks-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-flag-o"></i>
              <span class="label label-danger">9</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">You have 9 tasks</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <li><!-- Task item -->
                    <a href="#">
                      <h3>
                        Design some buttons
                        <small class="pull-right">20%</small>
                      </h3>
                      <div class="progress xs">
                        <div class="progress-bar progress-bar-aqua" style="width: 20%" role="progressbar"
                             aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">
                          <span class="sr-only">20% Complete</span>
                        </div>
                      </div>
                    </a>
                  </li>
                  <!-- end task item -->
                  <li><!-- Task item -->
                    <a href="#">
                      <h3>
                        Create a nice theme
                        <small class="pull-right">40%</small>
                      </h3>
                      <div class="progress xs">
                        <div class="progress-bar progress-bar-green" style="width: 40%" role="progressbar"
                             aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">
                          <span class="sr-only">40% Complete</span>
                        </div>
                      </div>
                    </a>
                  </li>
                  <!-- end task item -->
                  <li><!-- Task item -->
                    <a href="#">
                      <h3>
                        Some task I need to do
                        <small class="pull-right">60%</small>
                      </h3>
                      <div class="progress xs">
                        <div class="progress-bar progress-bar-red" style="width: 60%" role="progressbar"
                             aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">
                          <span class="sr-only">60% Complete</span>
                        </div>
                      </div>
                    </a>
                  </li>
                  <!-- end task item -->
                  <li><!-- Task item -->
                    <a href="#">
                      <h3>
                        Make beautiful transitions
                        <small class="pull-right">80%</small>
                      </h3>
                      <div class="progress xs">
                        <div class="progress-bar progress-bar-yellow" style="width: 80%" role="progressbar"
                             aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">
                          <span class="sr-only">80% Complete</span>
                        </div>
                      </div>
                    </a>
                  </li>
                  <!-- end task item -->
                </ul>
              </li>
              <li class="footer">
                <a href="#">View all tasks</a>
              </li>
            </ul>
          </li>
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="<?=PROOT?>assets/img/logo_vbg.png" class="user-image" alt="User Image">
              <span class="hidden-xs"><?=Users::currentUser()->fname . " " .Users::currentUser()->lname?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="<?=PROOT?>" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="<?=PROOT?>register/logout" class="btn btn-default btn-flat"><i class="fa fa-power-off"></i> Sair</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
         
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  

<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?=PROOT?>assets/img/logo_vbg.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?=Users::currentUser()->fname . " " .Users::currentUser()->lname?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- search form -->
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Pesquisar...">
          <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">VBG - MENU PRINCIPAL</li>
        <li class="active ">
          <a href="<?=PROOT?>">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>
    
        <li>
          <a href="<?=PROOT?>evaluation">
            <i class="fa fa-dashboard"></i> <span>Avalições</span>
          </a>
        </li>
    
         <li class="treeview">
          <a href="#">
            <i class="fa fa-cogs"></i>
            <span>Configurações</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?=PROOT?>setting/allCountry"><i class="fa fa-circle-o"></i> Países</a></li>
            <li><a href="<?=PROOT?>setting/allProvince"><i class="fa fa-circle-o"></i> Províncias</a></li>
            <li><a href="<?=PROOT?>setting/allDistrict"><i class="fa fa-circle-o"></i> Distritos</a></li>
            <li><a href="<?=PROOT?>setting/allDistrict"><i class="fa fa-circle-o"></i> Postos Administrativos</a></li>
            <li><a href="<?=PROOT?>setting/allDistrict"><i class="fa fa-circle-o"></i> Localidades</a></li>
            <li><a href="<?=PROOT?>setting/allDistrict"><i class="fa fa-circle-o"></i> Bairros</a></li>
            <li><a href="<?=PROOT?>setting/allService"><i class="fa fa-cog"></i> Serviços</a></li>
            <li><a href="<?=PROOT?>setting/allSub_service"><i class="fa fa-cog"></i> Sub-Serviços</a></li>
            <li><a href="<?=PROOT?>setting/allType_service"><i class="fa fa-cog"></i> Tipos Serviços</a></li>
            <li><a href="<?=PROOT?>setting/allSanitaryUnit"><i class="fa fa-circle-o"></i> Área em Avaliação</a></li>
            <li><a href="<?=PROOT?>setting/allArea"><i class="fa fa-circle-o"></i> Área Técnica</a></li>
            <li><a href="<?=PROOT?>setting/allCriterion_evaluation"><i class="fa fa-circle-o"></i> Critérios de Avaliações</a></li>
            <li><a href="<?=PROOT?>setting/allArea_padrao"><i class="fa fa-circle-o"></i> Padrões</a></li>
            <li><a href="<?=PROOT?>setting/allMeansVerification"><i class="fa fa-circle-o"></i> Meios de Verificação</a></li>
            <li><a href="<?=PROOT?>setting/allEvaluationType"><i class="fa fa-circle-o"></i> Tipos de Avaliação</a></li>
            <li><a href="<?=PROOT?>setting/allCategory"><i class="fa fa-circle-o"></i> Categoria de Utilizadores</a></li>
            <li><a href="<?=PROOT?>setting/allEmployment"><i class="fa fa-circle-o"></i> Função do Utilizador</a></li>
            <li><a href="<?=PROOT?>users/allUsers"><i class="fa fa-circle-o"></i> Contas do Utilizador</a></li>
            <li><a href="<?=PROOT?>setting/allInstance"><i class="fa fa-circle-o"></i> Instâncias</a></li>
            <li><a href="<?=PROOT?>setting/allCause"><i class="fa fa-circle-o"></i> Causas</a></li>
            <li><a href="<?=PROOT?>setting/allCauseType"><i class="fa fa-circle-o"></i> Tipos de Causas</a></li>
            <li><a href="<?=PROOT?>setting/allIntervention"><i class="fa fa-circle-o"></i> Intervenção</a></li>
          </ul>
        </li>
        <li class="treeview disabled">
          <a href="#">
            <i class="fa fa-pie-chart"></i>
            <span>Relatórios</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
        <!--  <ul class="treeview-menu">
            <li><a href="#"><i class="fa fa-circle-o"></i> Provinciais</a></li>
            <li><a href="#"><i class="fa fa-circle-o"></i> Distritais</a></li>
            <li><a href="#"><i class="fa fa-circle-o"></i> Por US</a></li>
            <li><a href="#"><i class="fa fa-circle-o"></i> Por Parceiro</a></li>
            <li><a href="#"><i class="fa fa-circle-o"></i> Por Provedor</a></li>
          </ul> -->
        </li>
        <li><a><i class="fa fa-book"></i> <span>Documentação</span></a></li>
        <li class="header">Manuais de Suporte</li>
        <li><a><i class="fa fa-circle-o text-red"></i> <span>Manual do utilizador</span></a></li>
        <li><a><i class="fa fa-circle-o text-yellow"></i> <span>Suporte Educacional</span></a></li>

       <!--    <li><a href="#"><i class="fa fa-circle-o text-aqua"></i> <span>Information</span></a></li>
      -->
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
