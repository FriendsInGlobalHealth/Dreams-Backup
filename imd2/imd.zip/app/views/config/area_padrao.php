<?php 
    use Core\FH;
    use Core\H;
	use Core\Alert;
	$this->setSiteTitle('Gerir Área Padrão | ' .SITE_TITLE);
	$this->start('body');
?>
  <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-lg-12">
                <?php if (isset($_SESSION['CURRENT_MSG'])): ?>
                    <?= Alert::displayAlert($_SESSION['CURRENT_MSG'], $_SESSION['CURRENT_MSG_TEXT']); ?>
                <?php unset($_SESSION['CURRENT_MSG']);unset($_SESSION['CURRENT_MSG_TEXT']); endif ?>
            </div>
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-md-10">
                                <h3 class="panel-title">Lista de Áreas Padrão</h3>
                            </div>
                            <div class="col-md-2" align="right">
                                <button type="button" name="add" id="add_button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#modal-default"><i class="fa fa-plus"></i> Add</button>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <table id="" class="table table-bordered table-striped table-dinamic">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Área</th>
                                    <th>Área Padrão</th>
                                    <th>Status</th>
                                    <th>Criado Por</th>
                                    <th>Horas</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($this->allArea_padrao as $key => $value): ?>
                                <tr>
                                    <td class="text-center small"><?=$value->id?></td>
                                    <td class="text-center small"><?=$value->area_id?></td>
                                    <td class=""><?=$value->name?></td>
                                    <td class="text-center small">
                                        <?php 
                                        if ($value->status == "Activo") {
                                            echo "<span class='label label-success label-xs'>".$value->status."</span>";
                                        }elseif (empty($value->status)) {
                                            echo "<span class='label label-default label-xs'>None</span>";
                                        }elseif ($value->status == "Inactivo") {
                                            echo "<span class='label label-danger label-xs'>".$value->status."</span>";
                                        }
                                            ?>
                                    </td>
                                    <td class=""><?=$value->DateCreateUser?></td>
                                    <td class=""><?=$value->DateCreate?></td>
                                    <td class="" class="datatable-ct">
                                        <div class="btn-group btn-group-xs">
                                            <a href="<?=PROOT?>setting/editArea_padrao/<?=$value->id?>" title="Editar" class="btn btn-xs btn-default" ><i class="fa fa-pencil text-success"></i></a>
                                            <a href="<?=PROOT?>setting/deleteArea_padrao/<?=$value->id?>" title="Remover" onclick="if(!confirm('Tem certeza que deseja remover esta Área?')){return false;}" class="btn btn-xs btn-default" ><i class="fa fa-close text-danger"></i></a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="modal-default">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="<?=PROOT?>setting/allArea_padrao"  method="post" accept-charset="utf-8"  enctype="multipart/form-data" class="">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <h4 class="modal-title"><i class="fa fa-plus"></i> Add Área Padrão</h4>
                        </div>
                        <div class="modal-body">
                            <div class="box-body">
                                <?= FH::csrfInput() ?>
                                <?= FH::textareaBlock('Nome','name',$this->newArea_padrao->name,['placeholder'=>'Nome', 'class'=>'form-control'],['class'=>'form-group'],$this->displayErrors) ?>
                                <?= FH::selectBlock('Área','area_id',$this->newArea_padrao->area_id,$this->allArea,['class'=>'form-control show-tick','title'=>'_ Selecionar _', 'required'=>'required','data-live-search'=>'true'],['class'=>'form-group'],$this->displayErrors)?>
                                <?= FH::selectBlock('Estado','status',$this->newArea_padrao->status,[''=>'_Selecionar_','Activo'=>'Activo', 'Inactivo'=>'Inactivo'],['class'=>'form-control show-tick','title'=>'_ Selecionar _', 'required'=>'required','data-live-search'=>'true'],['class'=>'form-group'],$this->displayErrors)?>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <?= FH::submitTag('Save',['class'=>'btn btn-success widget-btn-3']); ?>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
    </section>
</div>



<?php $this->end('body');