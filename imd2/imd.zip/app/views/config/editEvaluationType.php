<?php 
use Core\FH;
use Core\H;
    $this->setSiteTitle('Editar Tipo de Avaliação | ' .SITE_TITLE);
    $this->start('body');
?>
 <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?=PROOT?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?=PROOT?>setting/allEvaluationType"><i class="fa fa-dashboard"></i> Tipos de Avaliações</a></li>
        <li class="active">Editar</li>
      </ol>
    </section>
    <section class="content">
                <?php if (isset($_SESSION['CURRENT_MSG'])): ?>
                    <?= Alert::displayAlert($_SESSION['CURRENT_MSG'], $_SESSION['CURRENT_MSG_TEXT']); ?>
                <?php unset($_SESSION['CURRENT_MSG']);unset($_SESSION['CURRENT_MSG_TEXT']); endif ?>
            <div class="box box-info">
            <div class="box-header with-border">
                <h3 class="panel-title">Editar Tipo de Avaliação</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <div class="">
                <form action="<?=PROOT?>setting/editEvaluationType/<?=$this->updateEvaluationType->id?>"  method="post" accept-charset="utf-8"  enctype="multipart/form-data" class="panel-body">
                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-10">
                                <?= FH::csrfInput() ?>
                                <?= FH::displayErrors($this->displayErrors) ?>
                                <?= FH::inputBlock('text','Nome','name',$this->updateEvaluationType->name,['placeholder'=>'Nome', 'class'=>'form-control'],['class'=>'form-group'],$this->displayErrors) ?>
                                <?= FH::selectBlock('Estado','status',$this->updateEvaluationType->status,[''=>'_Selecionar_','Activo'=>'Activo', 'Inactivo'=>'Inactivo'],['class'=>'form-control show-tick','title'=>'_ Selecionar _', 'required'=>'required','data-live-search'=>'true'],['class'=>'form-group'],$this->displayErrors)?>
                            </div>
                        </div>
                    <!-- /.box-body -->
                    <div class="box-footer">
                        <div class="col-sm-offset-2 col-sm-10">
                            <a href="javascript:history.go(-1)" class="btn btn-default">Cancel</a>
                            <?= FH::submitTag('Save',['class'=>'btn btn-primary']) ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </section>
</div>
<?php $this->end('body'); ?>
