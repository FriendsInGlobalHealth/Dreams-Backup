<?php 
    use Core\FH;
    use Core\H;
    use Core\Alert;
    $this->setSiteTitle('Gerir Critério de Avaliação | ' .SITE_TITLE);
    $this->start('body');
?>
  <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Critério de Avaliação
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Critério de Avaliação</li>
      </ol>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-lg-12">
                <?php if (isset($_SESSION['CURRENT_MSG'])): ?>
                    <?= Alert::displayAlert($_SESSION['CURRENT_MSG'], $_SESSION['CURRENT_MSG_TEXT']); ?>
                <?php unset($_SESSION['CURRENT_MSG']);unset($_SESSION['CURRENT_MSG_TEXT']); endif ?>
            </div>
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-md-10">
                                <h3 class="panel-title">Lista de Critério de Avaliação</h3>
                            </div>
                            <div class="col-md-2" align="right">
                                <button type="button" name="add" id="add_button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#modal-default"><i class="fa fa-plus"></i> Add</button>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <table id="" class="table table-bordered table-striped table-dinamic">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Área</th>
                                    <th>Área Padrão</th>
                                    <th>Critério</th>
                                    <th>Control</th>
                                    <th>Status</th>
                                    <th>Meios</th>
                                    <th>Criado Por</th>
                                    <th>Horas</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($this->allCriterion_evaluation as $key => $value): ?>
                                <tr>
                                    <td class="text-center small"><?=$value->id?></td>
                                    <td class="text-center small"><?=$value->area_id?></td>
                                    <td class="text-center small"><?=$value->area_padrao_id?></td>
                                    <td class=""><?=$value->name?></td>
                                    <td class="text-center small">
                                        <?php 
                                        if ($value->control == "1") {
                                            echo "<span class='label label-success label-xs'>Sim</span>";
                                        }elseif ($value->control == "0") {
                                            echo "<span class='label label-danger label-xs'>Não</span>";
                                        }elseif (empty($value->control)) {
                                            echo "<span class='label label-default label-xs'>None</span>";
                                        }
                                            ?>
                                    </td>
                                    <td class="text-center small">
                                        <?php 
                                        if ($value->status == "Activo") {
                                            echo "<span class='label label-success label-xs'>".$value->status."</span>";
                                        }elseif (empty($value->status)) {
                                            echo "<span class='label label-default label-xs'>None</span>";
                                        }elseif ($value->status == "Inactivo") {
                                            echo "<span class='label label-danger label-xs'>".$value->status."</span>";
                                        }
                                            ?>
                                    </td>
                                    <td class=""><?=$value->means_verification?></td>
                                    <td class=""><?=$value->DateCreateUser?></td>
                                    <td class=""><?=$value->DateCreate?></td>
                                    <td class="" class="datatable-ct">
                                        <div class="btn-group btn-group-xs">
                                            <a href="<?=PROOT?>setting/editCriterion_evaluation/<?=$value->id?>" title="Editar" class="btn btn-xs btn-default" ><i class="fa fa-pencil text-success"></i></a>
                                            <a href="<?=PROOT?>setting/deleteCriterion_evaluation/<?=$value->id?>" title="Remover" onclick="if(!confirm('Tem certeza que deseja remover esta Área?')){return false;}" class="btn btn-xs btn-default" ><i class="fa fa-close text-danger"></i></a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="modal-default">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="<?=PROOT?>setting/allCriterion_evaluation"  method="post" accept-charset="utf-8"  enctype="multipart/form-data" class="">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <h4 class="modal-title"><i class="fa fa-plus"></i> Add Critério de Avaliação</h4>
                        </div>
                        <div class="modal-body">
                            <div class="box-body">
                                <?= FH::csrfInput() ?>
                                <?= FH::textareaBlock('Nome','name',$this->newCriterion_evaluation->name,['placeholder'=>'Nome', 'class'=>'form-control','rows'=>'5'],['class'=>'form-group'],$this->displayErrors) ?>
                                <?= FH::selectBlock('Área Técnica','area_id',$this->newCriterion_evaluation->area_id,$this->allArea,['class'=>'form-control show-tick','title'=>'_ Selecionar _', 'required'=>'required','data-live-search'=>'true'],['class'=>'form-group'],$this->displayErrors)?>
                                <?= FH::selectBlock('Padrão','area_padrao_id',$this->newCriterion_evaluation->area_padrao_id,$this->allArea_padrao,['class'=>'form-control show-tick','title'=>'_ Selecionar _', 'required'=>'required','data-live-search'=>'true'],['class'=>'form-group'],$this->displayErrors)?>
                                <?= FH::selectBlock('Control de Verificação','control',$this->newCriterion_evaluation->control,[''=>'_Selecionar_','1'=>'Sim', '0'=>'Não'],['class'=>'form-control show-tick','title'=>'_ Selecionar _', 'required'=>'required','data-live-search'=>'true'],['class'=>'form-group'],$this->displayErrors)?>
                                <?= FH::inputBlock('text','Meios de Verificação','means_verification',$this->newCriterion_evaluation->means_verification,['placeholder'=>'', 'class'=>'form-control'],['class'=>'form-group'],$this->displayErrors) ?>
                                <?= FH::selectBlock('Estado','status',$this->newCriterion_evaluation->status,[''=>'_Selecionar_','Activo'=>'Activo', 'Inactivo'=>'Inactivo'],['class'=>'form-control show-tick','title'=>'_ Selecionar _', 'required'=>'required','data-live-search'=>'true'],['class'=>'form-group'],$this->displayErrors)?>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <?= FH::submitTag('Save',['class'=>'btn btn-success widget-btn-3']); ?>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
    </section>
</div>



<?php $this->end('body');