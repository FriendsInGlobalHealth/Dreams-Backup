
<?php $this->start('body'); ?>
<h1 class="text-center text-secondary">Welcome to Ruah MVC Framework!</h1>

<?php $this->end(); ?>
