<?php 
    use Core\FH;
    use Core\H;
    use Core\Alert;
	$this->setSiteTitle("Registo de Avaliação | " .SITE_TITLE);
	$this->start("body");
?>
  <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Registo de Avaliações
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Registo de Avaliações</li>
      </ol>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-lg-12">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <div class="row">
                            <div class="col-md-12 text-center text-uppercase">
                                <br>
                                <h1 class="panel-title"><strong>Selecionar Tipo de Avaliação</strong></h1>
                                <br>
                            </div>
                        </div>
                    </div>
                    <form action="<?=PROOT?>evaluation/setEvaluation"  method="post" accept-charset="utf-8"  enctype="multipart/form-data" class="">
                        <div class="box-body">
                            <br>

                            <?= FH::csrfInput() ?>
                            <div class="form-group">
                                <div class="row">
                                <div class="col-sm-offset-1 col-sm-8">
                                <?= FH::selectBlock('Tipo de Avaliação','name',$this->EvaluationType->name,['Interna'=>'Avaliação Interna','Externa'=>'Avaliação Externa'],['class'=>'form-control show-tick','title'=>'_ Selecione tipo de Avaliação  _', 'required'=>'required','data-live-search'=>'true'],['class'=>'form-group'],$this->displayErrors)?>
                            </div>
                        </div>
                        <div class="box-footer">
                            <div class="col-sm-offset-3 col-sm-9">
                                <br>
                                 <?= FH::submitTag('Prosseguir',['class'=>'btn btn-danger']) ?>
                                <br>
                                <br>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
</div>

<?=$this->end("body");
