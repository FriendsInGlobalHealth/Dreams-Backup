<?php 
    use Core\FH;
    use Core\H;
    use Core\Alert;
    use App\Models\Area;
    use App\Models\Criterion_evaluation;
    use App\Models\Area_padrao;
    use App\Models\District;
    use App\Models\Province;
    use App\Models\SanitaryUnit;
    use App\Models\EvaluationType;
	$this->setSiteTitle("Histórico de Registo de Avaliação | " .SITE_TITLE);
	$this->start("body");
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
        <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Avaliações Realizadas
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Registo de Avaliações</li>
      </ol>
    </section>
    <section class="content">
      <div class="row">
            <div class="col-lg-12">
                <?php if (isset($_SESSION['CURRENT_MSG'])): ?>
                    <?= Alert::displayAlert($_SESSION['CURRENT_MSG'], $_SESSION['CURRENT_MSG_TEXT']); ?>
                <?php unset($_SESSION['CURRENT_MSG']);unset($_SESSION['CURRENT_MSG_TEXT']); endif ?>
            </div>
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-md-10">
                                <h3 class="panel-title">Lista de Avaliações Realizadas</h3>
                            </div>
                            <div class="col-md-2" align="right">
                                <a href="evaluation/setEvaluation" name="Registrar Avaliação" id="add_button" class="btn btn-success btn-xs"><i class="fa fa-plus"></i> Registrar Avaliação</a>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <table class="table table-bordered table-striped table-dinamic">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Tipo</th>
                                    <th>Distrito</th>
                                    <th>Provincia</th>
                                    <th>Local</th>
                                    <th>Data</th>
                                    <th>Criado por</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php  foreach($this->allEvaluationType as $key => $value):
                                ?>
                                <tr>
                                    <td class="small"><?=$value->id?></td>
                                    <td class="small"><abbr class="initialism" title="<?=$value->name?>"><?=$value->name?></abbr></td>
                                    
                                    <td class="small"><?php 
                                    $District = District::findById((int)$value->district_id);
                                    if ($District) {?>
                                        <abbr class="initialism"  title="<?=$District->name?>"><?=$District->name?></abbr>
                                    <?php }else{
                                        echo "<label class='label label-danger'>Não Encontrado</label>";
                                    }
                                     ?></td>
                                    <td class="small"><?php 
                                    $Province = Province::findById((int)$District->province_id);
                                    if ($Province) {?>
                                        <abbr class="initialism"  title="<?=$Province->name?>"><?=$Province->name?></abbr>
                                    <?php }else{
                                        echo "<label class='label label-danger'>Não Encontrado</label>";
                                    }
                                     ?></td>
                                    <td class="small"><?php 
                                    $SanitaryUnit = SanitaryUnit::findById((int)$value->sanitary_unit_id);
                                    if ($SanitaryUnit) {?>
                                         <abbr class="initialism"  title="<?=$SanitaryUnit->name?>"><?=$SanitaryUnit->name?></abbr>
                                    <?php }else{
                                        echo "<label class='label label-danger'>Não Encontrado</label>";
                                    }
                                     ?></td>
                                    
                                    <td class="small"><?=$value->date?></td>
                                    <td class="small"><?=$value->DateCreateUser?></td>
                                    <td class="text-center">
                                        <div class="btn-group btn-group-xs">
                                            <a href="<?=PROOT?>evaluation/detailEvaluationType/<?=$value->id?>" title="Editar" class="btn btn-xs btn-success" ><i class="fa fa-eye"></i> Ver avaliação</a>
                                            <a href="<?=PROOT?>evaluation/editEvaluationType/<?=$value->id?>" title="Editar" class="btn btn-xs btn-default" ><i class="fa fa-pencil text-success"></i></a>
                                            <a href="<?=PROOT?>evaluation/deleteEvaluationType/<?=$value->id?>" title="Remover" onclick="if(!confirm('Tem certeza que deseja remover este Distritos?')){return false;}" class="btn btn-xs btn-default" ><i class="fa fa-close text-danger"></i></a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
  </div>

<?=$this->end("body");