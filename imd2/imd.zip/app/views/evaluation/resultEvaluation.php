<?php 
    use Core\FH;
    use Core\H;
    use Core\Alert;
    use App\Models\Area;
    use App\Models\Criterion_evaluation;
    use App\Models\Area_padrao;
	$this->setSiteTitle("Histórico de Registo de Avaliação | " .SITE_TITLE);
	$this->start("body");
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
        <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Registo de Avaliações
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Registo de Avaliações</li>
      </ol>
    </section>
    <section class="content">
      <div class="row">
            <div class="col-lg-12">
                <?php if (isset($_SESSION['CURRENT_MSG'])): ?>
                    <?= Alert::displayAlert($_SESSION['CURRENT_MSG'], $_SESSION['CURRENT_MSG_TEXT']); ?>
                <?php unset($_SESSION['CURRENT_MSG']);unset($_SESSION['CURRENT_MSG_TEXT']); endif ?>
            </div>
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-md-10">
                                <h3 class="panel-title">Lista de Critério de Avaliação</h3>
                            </div>
                            <div class="col-md-2" align="right">
                                <button type="button" name="add" id="add_button" class="btn btn-success btn-xs" data-toggle="modal" data-target="#modal-default"><i class="fa fa-plus"></i> Add</button>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <table class="table table-bordered table-striped table-dinamic">
                            <thead class="bg-red">
                                <tr>
                                    <th class="text-center" width="200px">Área Avaliada</th>
                                    <th class="text-center" width="250px">Padrões de Qualidade Avaliados</th>
                                    <th class="text-center" width="200px">Criterios de  Verificação avaliados</th>
                                    <th>Lacunas</th>
                                    <th class="text-center">Resultados</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach (Area::findAll() as $key => $value): ?>
                                <tr>
                                    <td class="bg-black" style="padding: .5em; border-color: #ccc;"><?=$value->name?></td>
                                    <td class="small">
                                      <?php 
                                        $valuePadrao = Area_padrao::findByArea((int)$value->id);
                                        if($valuePadrao){
                                          echo $valuePadrao->name;
                                        }
                                      ?>
                                    </td>
                                    <td class="small">
                                      <?php 
                                        $valuePadrao = Area_padrao::findByArea((int)$value->id);
                                        if($valuePadrao){
                                          $i =0;
                                          foreach ($this->allEvaluation as $valueEvaluation) {
                                            $i++;
                                            echo $i.".".$valueEvaluation->id.", ";
                                          }
                                        }
                                      ?>
                                    </td>
                                    <td class=""></td>
                                    <td class="text-center">
                                        <?php 
                                        $percentagem = random_int(25, 100);
                                        if ($percentagem > 49) {
                                            $setColor = "#00a65a";
                                        }else{
                                            $setColor = "#dd4b39";
                                        }
                                        ?>
                                      <input type="text" class="knob" value="<?=$percentagem;?>" data-skin="tron" data-thickness="0.2" data-width="50" data-height="50" data-fgColor="<?=$setColor?>" data-readonly="true">
                                    </td>
                                </tr>
                                <?php endforeach ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
  </div>

<?=$this->end("body");