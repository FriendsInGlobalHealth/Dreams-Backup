<?php 
    use Core\FH;
    use App\Models\Users;
    use Core\H;
    use Core\Alert;
    use App\Models\Area;
    use App\Models\District;
    use App\Models\Area_padrao;
    use App\Models\Criterion_evaluation;
    use App\Models\SanitaryUnit;
	$this->setSiteTitle("Registo de Avaliação | " .SITE_TITLE);
	$this->start("body");
?>
  <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Registo de Avaliações
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Registo de Avaliações</li>
      </ol>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-lg-12">
                <?php if (isset($_SESSION['CURRENT_MSG'])): ?>
                    <?= Alert::displayAlert($_SESSION['CURRENT_MSG'], $_SESSION['CURRENT_MSG_TEXT']); ?>
                <?php unset($_SESSION['CURRENT_MSG']);unset($_SESSION['CURRENT_MSG_TEXT']); endif ?>
            </div>
            <div class="col-lg-12">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <div class="row">
                            <div class="col-md-12">
                                <h3 class="panel-title">
                                    <?php
                                    $SanitaryUnit = SanitaryUnit::findById((int)$this->currentEvaluationType->sanitary_unit_id);
                                    $District = District::findById((int)$this->currentEvaluationType->district_id);
                                    ?>
                                    <strong><?=$SanitaryUnit->name?></strong> - 
                                    Distrito de <?=$District->name?> - Avaliação <?=$this->currentEvaluationType->name?>
                                    </h3>
                            </div>
                        </div>
                    </div>
                    <form action="<?=PROOT?>evaluation/evaluating/" method="post" accept-charset="utf-8">
                        <div class="box-body">
                            <?php 
                            if(empty($this->newEvaluation->date)){
                                $this->newEvaluation->date = date("m/d/Y");
                            }
                            ?>
                    		<?= FH::csrfInput() ?>
                        </div>
                        <div class="box-body">
                            <table class="table table-bordered">
                                <thead class="bg-danger" style="color: white">
                                    <tr>
                                        <th>Critérios de Verificação</th>
                                        <th  width="120px">Meios de Verificação</th>
                                        <th  width="100px">Sim/Não</th>
                                        <th  width="120px">Comentários</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach (Area::findAll() as $key => $value): ?>
                                    <tr>
                                        <td colspan="4" style="padding: 0;">
                                            <p class="bg-black" style="padding: .5em"><?=$value->name?></p>
                                            <table class="table" style="padding: 0;">
                                                <tbody>
                                                    <?php $i=0; foreach (Area_padrao::findByUniqueArea((int)$value->id) as $values): ?>
                                                    <tr style="padding: 0;">
                                                        <td colspan="4" style="padding: 0;">
                                                            <div class="box box-default  collapsed-box box-solid">
                                                                <div class="box-header with-border">
                                                                    <h4 class="box-title"><?php $i++; echo $i.". ".$values->name ?> </h4>
                                                                    <div class="box-tools pull-right">
                                                                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i>
                                                                    </button>
                                                                    </div>
                                                                    <!-- /.box-tools -->
                                                                </div>
                                                                <!-- /.box-header -->
                                                                <div class="box-body">
                                                                    <table class="table table-bordered table-striped table-condensed">
                                                                        <tbody>
                                                                            <?php $ii=0; $iii=1; $iv=0; foreach (Criterion_evaluation::findByAreaPadrao((int)$values->id) as $values_criterion): ?>
                                                                            <tr>
                                                                                <td><?php $ii++;$iii++; $iv++; echo nl2br($i.". ".$ii.". ".$values_criterion->name); ?>
                                                                                    <?= FH::inputBlock('hidden','','criterion_evaluation_id_'.$ii,$values_criterion->id,['class'=>'form-control'],['class'=>'form-group'],$this->displayErrors) ?>
                                                                                    <?= FH::inputBlock('hidden','','total_rows',$ii,['class'=>'form-control'],['class'=>'form-group'],$this->displayErrors) ?>
                                                                                </td>
                                                                                <td width="120px"><?=$values_criterion->means_verification?>
                                                                                    
                                                                                </td>
                                                                                <td width="100px">
                                                                                    <?= FH::radioBlock('Sim','status_yes','status_yes_'.$ii,'Sim',[],['class'=>'flat-red'],$this->displayErrors) ?>
                                                                                    <?= FH::radioBlock('Não','status_yes','status_yes_'.$ii,'Não',[],['class'=>'flat-red'],$this->displayErrors) ?>
                                                                                </td>
                                                                                <td width="120px"><?= FH::commentBlock('comment_'.$ii,$this->newEvaluation->comment,['class'=>'form-control'],['class'=>'form-group'],$this->displayErrors) ?></td>
                                                                            </tr>
                                                                            <?php endforeach ?>
                                                                        </tbody>
                                                                    </table>
                                                                </div>
                                                            <!-- /.box-body -->
                                                        </div>
                                                        </td>
                                                    </tr>
                                                    <?php endforeach ?>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                    <?php endforeach ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="box-body">
                            <div class="text-center col-sm-12">
                                <?= FH::submitTag('Salvar Avaciação',['class'=>'btn btn-danger ']) ?>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
</div>

<?=$this->end("body");
