<?php 
    use Core\FH;
    use Core\H;
    use Core\Alert;
	$this->setSiteTitle("Registo de Avaliação | " .SITE_TITLE);
	$this->start("body");
?>
  <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Registo de Avaliações Internas
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Registo de Avaliações</li>
      </ol>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-lg-12">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <div class="row">
                            <div class="col-md-9">
                                <h3 class="panel-title">Avaliação Interna</h3>
                            </div>
                            <div class="col-md-3"></div>
                        </div>
                    </div>
                    <div class="box-body">
                    	<form action="<?=PROOT?>evaluation/internalEvaluation" method="get" accept-charset="utf-8">
                    		
                    	</form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?=$this->end("body");
