<?php 
    use Core\FH;
    use App\Models\Users;
    use Core\H;
    use Core\Alert;
    use App\Models\Area_padrao;
    use App\Models\Criterion_evaluation;
	$this->setSiteTitle("Registo de Avaliação | " .SITE_TITLE);
	$this->start("body");
?>
  <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Registo de Avaliações
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Registo de Avaliações</li>
      </ol>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-lg-12">
                <?php if (isset($_SESSION['CURRENT_MSG'])): ?>
                    <?= Alert::displayAlert($_SESSION['CURRENT_MSG'], $_SESSION['CURRENT_MSG_TEXT']); ?>
                <?php unset($_SESSION['CURRENT_MSG']);unset($_SESSION['CURRENT_MSG_TEXT']); endif ?>
            </div>
            <div class="col-lg-12">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <div class="row">
                            <div class="col-md-12 text-center text-uppercase">
                                <br>
                                <h1 class="panel-title"><strong>Avaliação <?=$this->type?></strong></h1>
                                <br>
                            </div>
                        </div>
                    </div>
                    <form action="<?=PROOT?>evaluation/newEvaluation/<?=$this->type?>" method="post" accept-charset="utf-8">
                        <div class="box-body">
                            <?php 
                            if(empty($this->newEvaluation->date)){
                                $this->newEvaluation->date = date("m/d/Y");
                            }
                            ?>
                    		<?= FH::csrfInput() ?>
                            <?= FH::selectBlock('Distrito','district_id',$this->newEvaluation->district_id,$this->allDistrict,['class'=>'form-control show-tick', 'required'=>'required','data-live-search'=>'true'],['class'=>'form-group'],$this->displayErrors)?>
                            <?= FH::selectBlock('Nome da U.S.','sanitary_unit_id',$this->newEvaluation->sanitary_unit_id,$this->allSanitaryUnit,['class'=>'form-control show-tick','required'=>'required','data-live-search'=>'true'],['class'=>'form-group'],$this->displayErrors)?>
                            <?= FH::inputBlockDate('text','Data de Registo','date',$this->newEvaluation->date,['class'=>'form-control datepicker'],['class'=>'form-group'],$this->displayErrors) ?>
                            <?= FH::selectBlock('Nome do Avaliador','user_id',$this->newEvaluation->user_id,Users::getOptionsForForm(),['class'=>'form-control show-tick', 'required'=>'required','data-live-search'=>'true'],['class'=>'form-group'],$this->displayErrors)?>
                            <?= FH::selectBlock('Cargo do Avaliador','employment_id',$this->newEvaluation->employment_id,$this->allEmployment,['class'=>'form-control show-tick', 'required'=>'required','data-live-search'=>'true'],['class'=>'form-group'],$this->displayErrors)?>
                            <?= FH::inputBlock('text','Equipa de Medição','team_medition',$this->newEvaluation->team_medition,['class'=>'form-control'],['class'=>'form-group'],$this->displayErrors) ?>
                            <?= FH::inputBlock('hidden','','name',$this->type,['class'=>'form-control'],['class'=>'form-group'],$this->displayErrors) ?>
                        </div>
                        <div class="box-body">
                            <div class="col-sm-offset-3 col-sm-10">
                                <?= FH::submitTag('Gerar',['class'=>'btn btn-success ']) ?>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
</div>

<?=$this->end("body");
