<?php
  namespace App\Models;
  use Core\Model;
  use Core\Validators\{RequiredValidator,UniqueValidator};

  class District extends Model{
    public $id, $name, $province_id, $DateCreate, $DateCreateUser, $LastUpDate, $LastUpDateUser, $status, $deleted = 0;
    protected static $_table = 'sa_district';
    protected static $_softDelete = true;

    public function beforeSave(){
      $this->timeStamps();
    }

    public function validator(){
      $this->runValidation(new RequiredValidator($this,['field'=>'name','msg'=>'Nome do distrito é um campo obrigatório.']));
      $this->runValidation(new RequiredValidator($this,['field'=>'province_id','msg'=>'Província é um campo obrigatório.']));
      $this->runValidation(new UniqueValidator($this,['field'=>['name','deleted'],'msg'=>'Este Distrito já existe.']));
    }

    public static function findById($id){
      return self::findFirst([
        'conditions' => "id = ?",
        'bind' => [$id]
      ]);
    }
    
    public static function findAll(){
      return self::find();
    }

    public static function getOptionsForForm(){
      $districts = self::find([
        'columns' => 'id,name',
        'conditions' => "status = 'Activo'",
        'order' => 'name'
      ]);
      foreach($districts as $district){
        $districtsAry[$district->id] = $district->name;
      }
      return $districtsAry;
    }

    public static function getOptionsById($id){
      $districts = self::find([
        'columns' => 'id,name',
        'conditions' => "status = 'Activo' AND id = {$id} ",
        'order' => 'name'
      ]);
      foreach($districts as $district){
        $districtsAry[$district->id] = $district->name;
      }
      return $districtsAry;
    }
  }
