<?php
  namespace App\Models;
  use Core\Model;
  use Core\Validators\{RequiredValidator,UniqueValidator};

  class Area_padrao extends Model{
    public $id, $name,$area_id, $DateCreate, $DateCreateUser, $LastUpDate, $LastUpDateUser, $status, $deleted = 0;
    protected static $_table = 'sa_area_padrao';
    protected static $_softDelete = true;

    public function beforeSave(){
      $this->timeStamps();
    }

    public function validator(){
      $this->runValidation(new RequiredValidator($this,['field'=>'name','msg'=>'Nome é um campo obrigatório.']));
      $this->runValidation(new RequiredValidator($this,['field'=>'area_id','msg'=>'Área é um campo obrigatório.']));
      $this->runValidation(new UniqueValidator($this,['field'=>['name','deleted'],'msg'=>'Este Padrão já existe.']));
    }

    public static function findById($id){
      return self::findFirst([
        'conditions' => "id = ?",
        'bind' => [$id]
      ]);
    }

    public static function findByArea($id){
      return self::findFirst([
        'conditions' => "area_id = ?",
        'bind' => [$id]
      ]);
    }

    public static function findByUniqueArea($id){
      return self::find([
        'conditions' => "area_id = ?",
        'bind' => [$id]
      ]);
    }
    
    public static function findAll(){
      return self::find();
    }

    public static function getOptionsForForm(){
      $area_padraos = self::find([
        'columns' => 'id,name',
        'conditions' => "status = 'Activo'",
        'order' => 'name'
      ]);
      foreach($area_padraos as $area_padrao){
        $area_padraosAry[$area_padrao->id] = $area_padrao->name;
      }
      return $area_padraosAry;
    }
  }
