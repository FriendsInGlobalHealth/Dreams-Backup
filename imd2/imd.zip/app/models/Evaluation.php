<?php

	namespace App\Models;
	use Core\Model;
	use Core\Validators\MinValidator;
	use Core\Validators\MaxValidator;
	use Core\Validators\RequiredValidator;
	use Core\Validators\EmailValidator;
	use Core\Validators\MatchesValidator;
	use Core\Validators\UniqueValidator;

	/**
	 * 
	 */
	class Evaluation extends Model {
    public $id, $name, $comment, $status_yes, $criterion_evaluation_id, $evaluation_type_id, $employment_id, $DateCreate, $DateCreateUser, $LastUpDate, $LastUpDateUser, $status, $deleted = 0;
    protected static $_table = 'sa_evaluation';
    protected static $_softDelete = true;

    public function beforeSave(){
      $this->timeStamps();
    }

    public function validator(){
      $this->runValidation(new RequiredValidator($this,['field'=>'criterion_evaluation_id','msg'=>'Critério de Avaliação é um campo obrigatório.']));
      $this->runValidation(new RequiredValidator($this,['field'=>'evaluation_type_id','msg'=>'Tipo de Avaliação é um campo obrigatório.']));
      // $this->runValidation(new UniqueValidator($this,['field'=>['date','sanitary_unit_id','district_id','deleted'],'msg'=>'Esta Avaliação já foi feita.']));
    }

    public static function findById($id){
      return self::findFirst([
        'conditions' => "id = ?",
        'bind' => [$id]
      ]);
    }
    
    public static function findAll(){
      return self::find();
    }

    public static function getOptionsForForm(){
      $evaluations = self::find([
        'columns' => 'id,name',
        'conditions' => "status = 'Activo'",
        'order' => 'name'
      ]);
      foreach($evaluations as $evaluation){
        $evaluationsAry[$evaluation->id] = $evaluation->name;
      }
      return $evaluationsAry;
    }
  }