<?php
  namespace App\Models;
  use Core\Model;
  use Core\Validators\{RequiredValidator,UniqueValidator};

  class Intervention extends Model{
    public $id, $name, $cause_id, $order_intervention, $DateCreate, $DateCreateUser, $LastUpDate, $LastUpDateUser, $status, $deleted = 0;
    protected static $_table = 'sa_intervention';
    protected static $_softDelete = true;

    public function beforeSave(){
      $this->timeStamps();
    }

    public function validator(){
      $this->runValidation(new RequiredValidator($this,['field'=>'cause_id','msg'=>'Informe a causa.']));
      $this->runValidation(new RequiredValidator($this,['field'=>'name','msg'=>'Nome é um campo obrigatório.']));
      $this->runValidation(new UniqueValidator($this,['field'=>['name','deleted'],'msg'=>'Esta intervenção já existe.']));
    }

    public static function findById($id){
      return self::findFirst([
        'conditions' => "id = ?",
        'bind' => [$id]
      ]);
    }
    
    public static function findAll(){
      return self::find();
    }

    public static function getOptionsForForm(){
      $interventions = self::find([
        'columns' => 'id,name',
        'conditions' => "status = 'Activo'",
        'order' => 'name'
      ]);
      foreach($interventions as $intervention){
        $interventionsAry[$intervention->id] = $intervention->name;
      }
      return $interventionsAry;
    }
  }
