<?php
  namespace App\Models;
  use Core\Model;
  use Core\Validators\{RequiredValidator,UniqueValidator};

  class Criterion_evaluation extends Model{
    public $id, $name,$area_id, $area_padrao_id, $means_verification, $descrition, $control, $DateCreate, $DateCreateUser, $LastUpDate, $LastUpDateUser, $status, $deleted = 0;
    protected static $_table = 'sa_criterion_evaluation';
    protected static $_softDelete = true;

    public function beforeSave(){
      $this->timeStamps();
    }

    public function validator(){
      $this->runValidation(new RequiredValidator($this,['field'=>'name','msg'=>'Nome é um campo obrigatório.']));
      $this->runValidation(new RequiredValidator($this,['field'=>'area_padrao_id','msg'=>'Área Padrão é um campo obrigatório.']));
      $this->runValidation(new RequiredValidator($this,['field'=>'area_id','msg'=>'Área é um campo obrigatório.']));
      // $this->runValidation(new RequiredValidator($this,['field'=>'means_verification','msg'=>'Meios de Verificação é um campo obrigatório.']));
      $this->runValidation(new RequiredValidator($this,['field'=>'control','msg'=>'Control de Verificação é um campo obrigatório.']));
      $this->runValidation(new UniqueValidator($this,['field'=>['name','deleted'],'msg'=>'Este Critério já existe.']));
    }

    public static function findById($id){
      return self::findFirst([
        'conditions' => "id = ?",
        'bind' => [$id]
      ]);
    }
    
    public static function findAll(){
      return self::find();
    }

    public static function findByAreaPadrao($id){
      return self::find([
        'conditions' => "area_padrao_id = ?",
        'bind' => [$id]
      ]);
    }

    public static function getOptionsForForm(){
      $criterion_evaluations = self::find([
        'columns' => 'id,name',
        'conditions' => "status = 'Activo'",
        'order' => 'name'
      ]);
      foreach($criterion_evaluations as $criterion_evaluation){
        $criterion_evaluationsAry[$criterion_evaluation->id] = $criterion_evaluation->name;
      }
      return $criterion_evaluationsAry;
    }
  }
