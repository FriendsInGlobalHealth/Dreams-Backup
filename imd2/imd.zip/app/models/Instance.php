<?php
  namespace App\Models;
  use Core\Model;
  use Core\Validators\{RequiredValidator,UniqueValidator};

  class Instance extends Model{
    public $id, $name, $DateCreate, $DateCreateUser, $LastUpDate, $LastUpDateUser, $status, $deleted = 0;
    protected static $_table = 'sa_instance';
    protected static $_softDelete = true;

    public function beforeSave(){
      $this->timeStamps();
    }

    public function validator(){
      $this->runValidation(new RequiredValidator($this,['field'=>'name','msg'=>'Nome é um campo obrigatório.']));
      $this->runValidation(new UniqueValidator($this,['field'=>['name','deleted'],'msg'=>'Esta Unidade Sanitária já existe.']));
    }

    public static function findById($id){
      return self::findFirst([
        'conditions' => "id = ?",
        'bind' => [$id]
      ]);
    }
    
    public static function findAll(){
      return self::find();
    }

    public static function getOptionsForForm(){
      $instances = self::find([
        'columns' => 'id,name',
        'conditions' => "status = 'Activo'",
        'order' => 'name'
      ]);
      foreach($instances as $instance){
        $instancesAry[$instance->id] = $instance->name;
      }
      return $instancesAry;
    }

    public static function getOptionsById($id){
      $instances = self::find([
        'columns' => 'id,name',
        'conditions' => "status = 'Activo' AND id = {$id} ",
        'order' => 'name'
      ]);
      foreach($instances as $instance){
        $instancesAry[$instance->id] = $instance->name;
      }
      return $instancesAry;
    }
  }
