<?php
  namespace App\Models;
  use Core\Model;
  use Core\Validators\{RequiredValidator,UniqueValidator};

  class Employment extends Model{
    public $id, $name, $DateCreate, $DateCreateUser, $LastUpDate, $LastUpDateUser, $status, $deleted = 0;
    protected static $_table = 'sa_employment';
    protected static $_softDelete = true;

    public function beforeSave(){
      $this->timeStamps();
    }

    public function validator(){
      $this->runValidation(new RequiredValidator($this,['field'=>'name','msg'=>'Nome é um campo obrigatório.']));
      $this->runValidation(new UniqueValidator($this,['field'=>['name','deleted'],'msg'=>'Esta função já existe.']));
    }

    public static function findById($id){
      return self::findFirst([
        'conditions' => "id = ?",
        'bind' => [$id]
      ]);
    }
    
    public static function findAll(){
      return self::find();
    }

    public static function getOptionsForForm(){
      $employments = self::find([
        'columns' => 'id,name',
        'conditions' => "status = 'Activo'",
        'order' => 'name'
      ]);
      foreach($employments as $employment){
        $employmentsAry[$employment->id] = $employment->name;
      }
      return $employmentsAry;
    }

      public static function getOptionsById($id){
      $employments = self::find([
        'columns' => 'id,name',
        'conditions' => "status = 'Activo' AND id = {$id} ",
        'order' => 'name'
      ]);
      foreach($employments as $employment){
        $employmentsAry[$employment->id] = $employment->name;
      }
      return $employmentsAry;
    }
  }
