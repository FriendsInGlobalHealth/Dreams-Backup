<?php
  namespace App\Models;
  use Core\Model;
  use Core\Validators\{RequiredValidator,UniqueValidator};

  class EvaluationType extends Model{
    public $id, $name, $sanitary_unit_id, $district_id, $date, $user_id, $team_medition, $employment_id, $DateCreate, $DateCreateUser, $LastUpDate, $LastUpDateUser, $status, $deleted = 0;
    protected static $_table = 'sa_evaluation_type';
    protected static $_softDelete = true;

    public function beforeSave(){
      $this->timeStamps();
    }

    public function validator(){
      $this->runValidation(new RequiredValidator($this,['field'=>'name','msg'=>'Nome é um campo obrigatório.']));
      $this->runValidation(new RequiredValidator($this,['field'=>'sanitary_unit_id','msg'=>'Unidade Sanitaria é um campo obrigatório.']));
      $this->runValidation(new RequiredValidator($this,['field'=>'district_id','msg'=>'Distrito é um campo obrigatório.']));
      $this->runValidation(new RequiredValidator($this,['field'=>'date','msg'=>'Data de Avaliação é um campo obrigatório.']));
      $this->runValidation(new RequiredValidator($this,['field'=>'team_medition','msg'=>'Equipa de Medição é um campo obrigatório.']));
    }

    public static function findById($id){
      return self::findFirst([
        'conditions' => "id = ?",
        'bind' => [$id]
      ]);
    }
    
    public static function findAll(){
      return self::find();
    }

    public static function getOptionsForForm(){
      $evaluation_types = self::find([
        'columns' => 'id,name',
        'conditions' => "status = 'Activo'",
        'order' => 'name'
      ]);
      foreach($evaluation_types as $evaluation_type){
        $evaluation_typesAry[$evaluation_type->id] = $evaluation_type->name;
      }
      return $evaluation_typesAry;
    }

    public static function getOptionsForEvaluation(){
      $evaluation_types = self::find([
        'columns' => 'id,name',
        'conditions' => "status = 'Activo'",
        'order' => 'name'
      ]);
      foreach($evaluation_types as $evaluation_type){
        $evaluation_typesAry[$evaluation_type->name] = $evaluation_type->name;
      }
      return $evaluation_typesAry;
    }
  }
