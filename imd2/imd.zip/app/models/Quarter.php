<?php
  namespace App\Models;
  use Core\Model;
  use Core\Validators\{RequiredValidator,UniqueValidator};

  class Quarter extends Model{
    public $id, $name, $country_id, $province_id, $district_id, $DateCreate, $DateCreateUser, $LastUpDate, $LastUpDateUser, $status, $deleted = 0;
    protected static $_table = 'sa_quarter';
    protected static $_softDelete = true;

    public function beforeSave(){
      $this->timeStamps();
    }

    public function validator(){
      $this->runValidation(new RequiredValidator($this,['field'=>'country_id','msg'=>'País é um campo obrigatório.']));
      $this->runValidation(new RequiredValidator($this,['field'=>'province_id','msg'=>'Província é um campo obrigatório.']));
      $this->runValidation(new RequiredValidator($this,['field'=>'district_id','msg'=>'Distrito é um campo obrigatório.']));
      $this->runValidation(new RequiredValidator($this,['field'=>'administrative_post_id','msg'=>'Distrito é um campo obrigatório.']));
      $this->runValidation(new RequiredValidator($this,['field'=>'name','msg'=>'Nome é um campo obrigatório.']));
      $this->runValidation(new UniqueValidator($this,['field'=>['name','deleted'],'msg'=>'Este Bairro já existe.']));
    }

    public static function findById($id){
      return self::findFirst([
        'conditions' => "id = ?",
        'bind' => [$id]
      ]);
    }
    
    public static function findAll(){
      return self::find();
    }

    public static function getOptionsForForm(){
      $Quarters = self::find([
        'columns' => 'id,name',
        'conditions' => "status = 'Activo'",
        'order' => 'name'
      ]);
      foreach($Quarters as $Quarter){
        $QuartersAry[$Quarter->id] = $Quarter->name;
      }
      return $QuartersAry;
    }
  }
