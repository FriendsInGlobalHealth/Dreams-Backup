<?php
  namespace App\Controllers;
  use Core\Controller;
  use Core\Router;
  use App\Models\Users;

  class HomeController extends Controller {

     public function onConstruct(){
      $this->view->setLayout(LAYOUT_ADMIN);
    }

    public function indexAction() {
      if (!Users::currentUser()) {
        Router::redirect('register/login');
      }
      $this->view->render('dashboard/index');
    }
  }
