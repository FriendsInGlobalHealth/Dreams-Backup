<?php 
  namespace App\Controllers;
  use Core\Controller;
  use Core\Router;
  use App\Models\Evaluation;
    use App\Models\District;
    use App\Models\Country;
    use App\Models\Area;
    use App\Models\Criterion_evaluation;
    use App\Models\Province;
    use App\Models\Area_padrao;
    use App\Models\EvaluationType;
    use App\Models\MeansVerification;
    use App\Models\SanitaryUnit;
    use App\Models\Employment;
  use App\Models\Users;
  use Core\H;
  use Core\Session;

  class EvaluationController extends Controller {
  	
    public function onConstruct(){
      $this->view->setLayout(LAYOUT_ADMIN);
    }

    public function indexAction(){
    	$this->view->allEvaluationType = EvaluationType::findAll();
    	$this->view->render("evaluation/allEvaluation");
    }

    public function setEvaluationAction(){
    	$EvaluationType = new EvaluationType();
    	if($this->request->isPost()){
    		$this->request->csrfCheck();
    		$EvaluationType->assign($this->request->get());

    		if (isset($_POST['name'])) {
    			Router::redirect('evaluation/newEvaluation/'.$EvaluationType->name);
    		}else{
    			$EvaluationType->addErrorMessage('name','Selecione um tipo de Avaliação');
    		}
         }
        $this->view->EvaluationType = $EvaluationType;
    	$this->view->displayErrors = $EvaluationType->getErrorMessages();
    	$this->view->render("evaluation/index");
    }

    public function newEvaluationAction($type){
      $newEvaluation = new EvaluationType();
      if($this->request->isPost()){
          $this->request->csrfCheck();
          $newEvaluation->assign($this->request->get());
          $newEvaluation->DateCreateUser = Users::currentUser()->fname;
          $newEvaluation->DateCreate = date("l, j F Y H:i:s");

          if($newEvaluation->save()){
            if ($newEvaluation->validationPassed()){
              $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
              $_SESSION['CURRENT_MSG']  = "success";
              Router::redirect('evaluation/evaluating/'.$newEvaluation->id);
            }
          }else{
            $_SESSION['CURRENT_MSG'] = "error";
            $_SESSION['CURRENT_MSG_TEXT'] = $newEvaluation->getErrorMessages();
          }

      }

        if ($type == "Interna") {
          $this->view->allDistrict= District::getOptionsById((int)Users::currentUser()->district_id);
          $this->view->allSanitaryUnit= SanitaryUnit::getOptionsById((int)Users::currentUser()->sanitary_unit_id);
          $this->view->allUsers= Users::getOptionsById((int)Users::currentUser()->id);
          $this->view->allEmployment= Employment::getOptionsById((int)Users::currentUser()->employment_id);
          $this->view->type = "Interna";
        }elseif ($type == "Externa") {
          $this->view->allEvaluationType = EvaluationType::getOptionsForForm();
          $this->view->allDistrict= District::getOptionsForForm();
          $this->view->allSanitaryUnit= SanitaryUnit::getOptionsForForm();
          $this->view->allEmployment= Employment::getOptionsForForm();
          $this->view->allUsers= Users::getOptionsForForm();
          $this->view->type = "Externa";
        }

      $this->view->allArea = Area::findAll();
      $this->view->allArea_padrao = Area_padrao::findAll();
      $this->view->newEvaluation = $newEvaluation;
      $this->view->displayErrors = $newEvaluation->getErrorMessages();
    	$this->view->render("evaluation/newEvaluation");
    }

    public function evaluatingAction($id){
      $newEvaluation = new Evaluation();
      if($this->request->isPost()){
          $this->request->csrfCheck();
          $newEvaluation->assign($this->request->get());
          $newEvaluation->DateCreateUser = Users::currentUser()->fname;
          $newEvaluation->DateCreate = date("l, j F Y H:i:s");

          for ($i=1; $i < $_POST['total_rows']; $i++) { 
            $newEvaluation->comment = $_POST['comment_'.$i];
            $newEvaluation->status_yes = $_POST['status_yes_'.$i];
            $newEvaluation->criterion_evaluation_id = $_POST['criterion_evaluation_id_'.$i];
            $newEvaluation->avaluation_type_id  = $_POST['avaluation_type_id '];

            if($newEvaluation->save()){
              $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
              $_SESSION['CURRENT_MSG']  = "success";
            }else{
              $_SESSION['CURRENT_MSG_TEXT'] = $newEvaluation->getErrorMessages();
              $_SESSION['CURRENT_MSG'] = "error";
            }
          }
          
          if($newEvaluation->validationPassed()){
            $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
            $_SESSION['CURRENT_MSG']  = "success";
              Router::redirect("evaluation/resultEvaluation/".$newEvaluation->date."/".$newEvaluation->sanitary_unit_id);
          }else{
            $_SESSION['CURRENT_MSG_TEXT'] = $newEvaluation->getErrorMessages();
              $_SESSION['CURRENT_MSG'] = "error";
          }
        }

      $this->view->currentEvaluationType = EvaluationType::findById((int)$id);
      $this->view->newEvaluation = $newEvaluation;
      $this->view->displayErrors = $newEvaluation->getErrorMessages();
      $this->view->render("evaluation/evaluating");
    }

    public function resultEvaluationAction(){
      $this->view->allEvaluation = Evaluation::findAll();
    	$this->view->render("evaluation/resultEvaluation");
    }

    

  }