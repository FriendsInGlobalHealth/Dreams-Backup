<?php
    namespace App\Controllers;
    use Core\Controller;
    use Core\Router;
    use App\Models\District;
    use App\Models\Country;
    use App\Models\Area;
    use App\Models\Criterion_evaluation;
    use App\Models\Category;
    use App\Models\Cause;
    use App\Models\CauseType;
    use App\Models\Intervention;
    use App\Models\Employment;
    use App\Models\Province;
    use App\Models\Area_padrao;
    use App\Models\EvaluationType;
    use App\Models\Type_document;
    use App\Models\Users;
    use App\Models\MeansVerification;
    use App\Models\SanitaryUnit;
    use App\Models\Instance;
    use App\Lib\Utilities\Uploads;
    use Core\Session;
    use Core\H;

    class SettingController extends Controller {

        public function onConstruct(){
            $this->view->setLayout(LAYOUT_ADMIN);
        }

        public function indexAction(){
            $this->view->render("config/config.ini");
        }

        public function allCountryAction(){
            $newCountry = new Country();
            if($this->request->isPost()){
                $this->request->csrfCheck();
                $newCountry->assign($this->request->get());
                $newCountry->DateCreateUser = Users::currentUser()->fname;
                $newCountry->DateCreate = date("l, j F Y H:i:s");
                if($newCountry->save()){
                    $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                    $_SESSION['CURRENT_MSG']  = "success";
                    Router::redirect('setting/allCountry');
                }else{
                  $_SESSION['CURRENT_MSG'] = "error";
                  $_SESSION['CURRENT_MSG_TEXT'] = $newCountry->getErrorMessages();
                }
              }
            $this->view->newCountry = $newCountry;
            $this->view->allCountry = Country::findAll();
            $this->view->displayErrors = $newCountry->getErrorMessages();
            $this->view->render("config/country");
        }

        public function editCountryAction($id){
            $updateCountry = Country::findById((int)$id);
            if($this->request->isPost()){
                $this->request->csrfCheck();
                $updateCountry->assign($this->request->get());
                $updateCountry->LastUpDateUser = Users::currentUser()->fname;
                $updateCountry->LastUpDate = date("l, j F Y H:i:s");
                if($updateCountry->save()){
                    $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                    $_SESSION['CURRENT_MSG']  = "success";
                    Router::redirect('setting/allCountry');
                }else{
                  $_SESSION['CURRENT_MSG_TEXT'] = $updateCountry->getErrorMessages();
                  $_SESSION['CURRENT_MSG'] = "error";
                }
              }
            $this->view->updateCountry = $updateCountry;
            $this->view->displayErrors = $updateCountry->getErrorMessages();
            $this->view->render("config/editCountry");
        }

        public function deleteCountryAction($id){
          $deleteCountry = Country::findBYId((int)$id);
          if($deleteCountry){
            $deleteCountry->LastUpDate = date("l, j F Y H:i:s");
            $deleteCountry->delete();
            $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
            $_SESSION['CURRENT_MSG']  = "success";
            Router::redirect('setting/allCountry');
          }else {
            $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
            $_SESSION['CURRENT_MSG'] = "error";
            Router::redirect('setting/allCountry');
          }
        }

        /* Start Distritos */

        public function allDistrictAction(){
          $newDistrict = new District();
          if($this->request->isPost()){
              $this->request->csrfCheck();
              $newDistrict->assign($this->request->get());
              $newDistrict->DateCreateUser = Users::currentUser()->fname;
              $newDistrict->DateCreate = date("l, j F Y H:i:s");
              if($newDistrict->save()){
                  $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                  $_SESSION['CURRENT_MSG']  = "success";
                  Router::redirect('setting/allDistrict');
              }else{
                $_SESSION['CURRENT_MSG_TEXT'] = $newDistrict->getErrorMessages();
                $_SESSION['CURRENT_MSG'] = "error";
              }
            }
          $this->view->newDistrict = $newDistrict;
          $this->view->allDistrict = District::findAll();
          $this->view->allProvince = Province::getOptionsForForm();
          $this->view->displayErrors = $newDistrict->getErrorMessages();
          $this->view->render("config/District");
      }

      public function editDistrictAction($id){
          $updateDistrict = District::findById((int)$id);
          if($this->request->isPost()){
              $this->request->csrfCheck();
              $updateDistrict->assign($this->request->get());
              $updateDistrict->LastUpDateUser = Users::currentUser()->fname;
              $updateDistrict->LastUpDate = date("l, j F Y H:i:s");
              if($updateDistrict->save()){
                  $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                  $_SESSION['CURRENT_MSG']  = "success";
                  Router::redirect('setting/allDistrict');
              }else{
                $_SESSION['CURRENT_MSG_TEXT'] = $updateDistrict->getErrorMessages();
                $_SESSION['CURRENT_MSG'] = "error";
              }
            }
          $this->view->updateDistrict = $updateDistrict;
          $this->view->allProvince = Province::getOptionsForForm();
          $this->view->displayErrors = $updateDistrict->getErrorMessages();
          $this->view->render("config/editDistrict");
      }

      public function deleteDistrictAction($id){
        $deleteDistrict = District::findBYId((int)$id);
        if($deleteDistrict){
          $deleteDistrict->LastUpDate = date("l, j F Y H:i:s");
          $deleteDistrict->delete();
          $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
          $_SESSION['CURRENT_MSG']  = "success";
          Router::redirect('setting/allDistrict');
        }else {
          $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
          $_SESSION['CURRENT_MSG'] = "error";
          Router::redirect('setting/allDistrict');
        }
      }

      /** End Districo */
      /** Start Province */
      public function allProvinceAction(){
        $newProvince = new Province();
        if($this->request->isPost()){
            $this->request->csrfCheck();
            $newProvince->assign($this->request->get());
            $newProvince->DateCreateUser = Users::currentUser()->fname;
            $newProvince->DateCreate = date("l, j F Y H:i:s");
            if($newProvince->save()){
                $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                $_SESSION['CURRENT_MSG']  = "success";
                Router::redirect('setting/allProvince');
            }else{
              $_SESSION['CURRENT_MSG_TEXT'] = $newProvince->getErrorMessages();
              $_SESSION['CURRENT_MSG'] = "error";
            }
          }
        $this->view->newProvince = $newProvince;
        $this->view->allProvince = Province::findAll();
        $this->view->allCountry = Country::getOptionsForForm();
        $this->view->displayErrors = $newProvince->getErrorMessages();
        $this->view->render("config/Province");
    }

    public function editProvinceAction($id){
        $updateProvince = Province::findById((int)$id);
        if($this->request->isPost()){
            $this->request->csrfCheck();
            $updateProvince->assign($this->request->get());
            $updateProvince->LastUpDateUser = Users::currentUser()->fname;
            $updateProvince->LastUpDate = date("l, j F Y H:i:s");
            if($updateProvince->save()){
                $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                $_SESSION['CURRENT_MSG']  = "success";
                Router::redirect('setting/allProvince');
            }else{
              $_SESSION['CURRENT_MSG_TEXT'] = $updateProvince->getErrorMessages();
              $_SESSION['CURRENT_MSG'] = "error";
            }
          }
        $this->view->updateProvince = $updateProvince;
        $this->view->allCountry = Country::getOptionsForForm();
        $this->view->displayErrors = $updateProvince->getErrorMessages();
        $this->view->render("config/editProvince");
    }

    public function deleteProvinceAction($id){
      $deleteProvince = Province::findBYId((int)$id);
      if($deleteProvince){
        $deleteProvince->LastUpDate = date("l, j F Y H:i:s");
        $deleteProvince->delete();
        $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
        $_SESSION['CURRENT_MSG']  = "success";
        Router::redirect('setting/allProvince');
      }else {
        $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
        $_SESSION['CURRENT_MSG'] = "error";
        Router::redirect('setting/allProvince');
      }
    }
      /** End Province */

      /** Start Criterion_evaluation */
      public function allCriterion_evaluationAction(){
        $newCriterion_evaluation = new Criterion_evaluation();
        if($this->request->isPost()){
            $this->request->csrfCheck();
            $newCriterion_evaluation->assign($this->request->get());
            $newCriterion_evaluation->DateCreateUser = Users::currentUser()->fname;
            $newCriterion_evaluation->DateCreate = date("l, j F Y H:i:s");
            if($newCriterion_evaluation->save()){
                $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                $_SESSION['CURRENT_MSG']  = "success";
                Router::redirect('setting/allCriterion_evaluation');
            }else{
              $_SESSION['CURRENT_MSG_TEXT'] = $newCriterion_evaluation->getErrorMessages();
              $_SESSION['CURRENT_MSG'] = "error";
            }
          }
        $this->view->newCriterion_evaluation = $newCriterion_evaluation;
        $this->view->allCriterion_evaluation = Criterion_evaluation::findAll();
        $this->view->allArea_padrao = Area_padrao::getOptionsForForm();
        $this->view->allArea = Area::getOptionsForForm();
        $this->view->displayErrors = $newCriterion_evaluation->getErrorMessages();
        $this->view->render("config/Criterion_evaluation");
    }

    public function editCriterion_evaluationAction($id){
        $updateCriterion_evaluation = Criterion_evaluation::findById((int)$id);
        if($this->request->isPost()){
            $this->request->csrfCheck();
            $updateCriterion_evaluation->assign($this->request->get());
            $updateCriterion_evaluation->LastUpDateUser = Users::currentUser()->fname;
            $updateCriterion_evaluation->LastUpDate = date("l, j F Y H:i:s");
            if($updateCriterion_evaluation->save()){
                $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                $_SESSION['CURRENT_MSG']  = "success";
                Router::redirect('setting/allCriterion_evaluation');
            }else{
              $_SESSION['CURRENT_MSG_TEXT'] = $updateCriterion_evaluation->getErrorMessages();
              $_SESSION['CURRENT_MSG'] = "error";
            }
          }
        $this->view->updateCriterion_evaluation = $updateCriterion_evaluation;
        $this->view->allArea_padrao = Area_padrao::getOptionsForForm();
        $this->view->allArea = Area::getOptionsForForm();
        $this->view->displayErrors = $updateCriterion_evaluation->getErrorMessages();
        $this->view->render("config/editCriterion_evaluation");
    }

    public function deleteCriterion_evaluationAction($id){
      $deleteCriterion_evaluation = Criterion_evaluation::findBYId((int)$id);
      if($deleteCriterion_evaluation){
        $deleteCriterion_evaluation->delete();
        $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
        $_SESSION['CURRENT_MSG']  = "success";
        Router::redirect('setting/allProvince');
      }else {
        $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
        $_SESSION['CURRENT_MSG'] = "error";
        Router::redirect('setting/allCriterion_evaluation');
      }
    }

      /** Start Area */
      public function allAreaAction(){
        $newArea= new Area();
        if($this->request->isPost()){
            $this->request->csrfCheck();
            $newArea->assign($this->request->get());
            $newArea->DateCreateUser = Users::currentUser()->fname;
            $newArea->DateCreate = date("l, j F Y H:i:s");
            if($newArea->save()){
                $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                $_SESSION['CURRENT_MSG']  = "success";
                Router::redirect('setting/allArea');
            }else{
              $_SESSION['CURRENT_MSG_TEXT'] = $newArea->getErrorMessages();
              $_SESSION['CURRENT_MSG'] = "error";
            }
          }
        $this->view->newArea = $newArea;
        $this->view->allArea = Area::findAll();
        $this->view->displayErrors = $newArea->getErrorMessages();
        $this->view->render("config/Area");
    }

    public function editAreaAction($id){
        $updateArea = Area::findById((int)$id);
        if($this->request->isPost()){
            $this->request->csrfCheck();
            $updateArea->assign($this->request->get());
            $updateArea->LastUpDateUser = Users::currentUser()->fname;
            $updateArea->LastUpDate = date("l, j F Y H:i:s");
            if($updateArea->save()){
                $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                $_SESSION['CURRENT_MSG']  = "success";
                Router::redirect('setting/allArea');
            }else{
              $_SESSION['CURRENT_MSG_TEXT'] = $updateArea->getErrorMessages();
              $_SESSION['CURRENT_MSG'] = "error";
            }
          }
        $this->view->updateArea = $updateArea;
        $this->view->displayErrors = $updateArea->getErrorMessages();
        $this->view->render("config/editArea");
    }

    public function deleteAreaAction($id){
      $deleteArea= Area::findBYId((int)$id);
      if($deleteArea){
        $deleteArea->delete();
        $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
        $_SESSION['CURRENT_MSG']  = "success";
        Router::redirect('setting/allArea');
      }else {
        $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
        $_SESSION['CURRENT_MSG'] = "error";
        Router::redirect('setting/allArea');
      }
    }

      /** Start Area_padrao */
      public function allArea_padraoAction(){
        $newArea_padrao= new Area_padrao();
        if($this->request->isPost()){
            $this->request->csrfCheck();
            $newArea_padrao->assign($this->request->get());
            $newArea_padrao->DateCreateUser = Users::currentUser()->fname;
            $newArea_padrao->DateCreate = date("l, j F Y H:i:s");
            if($newArea_padrao->save()){
                $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                $_SESSION['CURRENT_MSG']  = "success";
                Router::redirect('setting/allArea_padrao');
            }else{
              $_SESSION['CURRENT_MSG_TEXT'] = $newArea_padrao->getErrorMessages();
              $_SESSION['CURRENT_MSG'] = "error";
            }
          }
        $this->view->newArea_padrao = $newArea_padrao;
        $this->view->allArea_padrao = Area_padrao::findAll();
        $this->view->allArea = Area::getOptionsForForm();
        $this->view->displayErrors = $newArea_padrao->getErrorMessages();
        $this->view->render("config/Area_padrao");
    }

    public function editArea_padraoAction($id){
        $updateArea_padrao = Area_padrao::findById((int)$id);
        if($this->request->isPost()){
            $this->request->csrfCheck();
            $updateArea_padrao->assign($this->request->get());
            $updateArea_padrao->LastUpDateUser = Users::currentUser()->fname;
            $updateArea_padrao->LastUpDate = date("l, j F Y H:i:s");
            if($updateArea_padrao->save()){
                $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                $_SESSION['CURRENT_MSG']  = "success";
                Router::redirect('setting/allArea_padrao');
            }else{
              $_SESSION['CURRENT_MSG_TEXT'] = $updateArea_padrao->getErrorMessages();
              $_SESSION['CURRENT_MSG'] = "error";
            }
          }
        $this->view->updateArea_padrao = $updateArea_padrao;
        $this->view->allArea = Area::getOptionsForForm();
        $this->view->displayErrors = $updateArea_padrao->getErrorMessages();
        $this->view->render("config/editArea_padrao");
    }

    public function deleteArea_padraoAction($id){
      $deleteArea_padrao= Area_padrao::findBYId((int)$id);
      if($deleteArea_padrao){
        $deleteArea_padrao->delete();
        $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
        $_SESSION['CURRENT_MSG']  = "success";
        Router::redirect('setting/allArea_padrao');
      }else {
        $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
        $_SESSION['CURRENT_MSG'] = "error";
        Router::redirect('setting/allArea_padrao');
      }
    }

      /** Start EvaluationType */
      public function allEvaluationTypeAction(){
        $newEvaluationType= new EvaluationType();
        if($this->request->isPost()){
            $this->request->csrfCheck();
            $newEvaluationType->assign($this->request->get());
            $newEvaluationType->DateCreateUser = Users::currentUser()->fname;
            $newEvaluationType->DateCreate = date("l, j F Y H:i:s");
            if($newEvaluationType->save()){
                $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                $_SESSION['CURRENT_MSG']  = "success";
                Router::redirect('setting/allEvaluationType');
            }else{
              $_SESSION['CURRENT_MSG_TEXT'] = $newEvaluationType->getErrorMessages();
              $_SESSION['CURRENT_MSG'] = "error";
            }
          }
        $this->view->newEvaluationType = $newEvaluationType;
        $this->view->allEvaluationType = EvaluationType::findAll();
        $this->view->displayErrors = $newEvaluationType->getErrorMessages();
        $this->view->render("config/evaluationType");
    }

    public function editEvaluationTypeAction($id){
        $updateEvaluationType = EvaluationType::findById((int)$id);
        if($this->request->isPost()){
            $this->request->csrfCheck();
            $updateEvaluationType->assign($this->request->get());
            $updateEvaluationType->LastUpDateUser = Users::currentUser()->fname;
            $updateEvaluationType->LastUpDate = date("l, j F Y H:i:s");
            if($updateEvaluationType->save()){
                $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                $_SESSION['CURRENT_MSG']  = "success";
                Router::redirect('setting/allEvaluationType');
            }else{
              $_SESSION['CURRENT_MSG_TEXT'] = $updateEvaluationType->getErrorMessages();
              $_SESSION['CURRENT_MSG'] = "error";
            }
          }
        $this->view->updateEvaluationType = $updateEvaluationType;
        $this->view->displayErrors = $updateEvaluationType->getErrorMessages();
        $this->view->render("config/editEvaluationType");
    }

    public function deleteEvaluationTypeAction($id){
      $deleteEvaluationType= EvaluationType::findBYId((int)$id);
      if($deleteEvaluationType){
        $deleteEvaluationType->delete();
        $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
        $_SESSION['CURRENT_MSG']  = "success";
        Router::redirect('setting/allEvaluationType');
      }else {
        $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
        $_SESSION['CURRENT_MSG'] = "error";
        Router::redirect('setting/allEvaluationType');
      }
    }

      /** Start MeansVerification */
      public function allMeansVerificationAction(){
        $newMeansVerification= new MeansVerification();
        if($this->request->isPost()){
            $this->request->csrfCheck();
            $newMeansVerification->assign($this->request->get());
            $newMeansVerification->DateCreateUser = Users::currentUser()->fname;
            $newMeansVerification->DateCreate = date("l, j F Y H:i:s");
            if($newMeansVerification->save()){
                $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                $_SESSION['CURRENT_MSG']  = "success";
                Router::redirect('setting/allMeansVerification');
            }else{
              $_SESSION['CURRENT_MSG_TEXT'] = $newMeansVerification->getErrorMessages();
              $_SESSION['CURRENT_MSG'] = "error";
            }
          }
        $this->view->newMeansVerification = $newMeansVerification;
        $this->view->allMeansVerification = MeansVerification::findAll();
        $this->view->allArea = Area::getOptionsForForm();
        $this->view->displayErrors = $newMeansVerification->getErrorMessages();
        $this->view->render("config/meansVerification");
    }

    public function editMeansVerificationAction($id){
        $updateMeansVerification = MeansVerification::findById((int)$id);
        if($this->request->isPost()){
            $this->request->csrfCheck();
            $updateMeansVerification->assign($this->request->get());
            $updateMeansVerification->LastUpDateUser = Users::currentUser()->fname;
            $updateMeansVerification->LastUpDate = date("l, j F Y H:i:s");
            if($updateMeansVerification->save()){
                $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                $_SESSION['CURRENT_MSG']  = "success";
                Router::redirect('setting/allMeansVerification');
            }else{
              $_SESSION['CURRENT_MSG_TEXT'] = $updateMeansVerification->getErrorMessages();
              $_SESSION['CURRENT_MSG'] = "error";
            }
          }
        $this->view->updateMeansVerification = $updateMeansVerification;
        $this->view->allArea = Area::getOptionsForForm();
        $this->view->displayErrors = $updateMeansVerification->getErrorMessages();
        $this->view->render("config/editMeansVerification");
    }

    public function deleteMeansVerificationAction($id){
      $deleteMeansVerification= MeansVerification::findBYId((int)$id);
      if($deleteMeansVerification){
        $deleteMeansVerification->delete();
        $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
        $_SESSION['CURRENT_MSG']  = "success";
        Router::redirect('setting/allMeansVerification');
      }else {
        $_SESSION['CURRENT_MSG_TEXT'] = $deleteMeansVerification->getErrorMessages();
        $_SESSION['CURRENT_MSG'] = "error";
        Router::redirect('setting/allMeansVerification');
      }
    }
      /** Start SanitaryUnit */
      public function allSanitaryUnitAction(){
        $newSanitaryUnit= new SanitaryUnit();
        if($this->request->isPost()){
            $this->request->csrfCheck();
            $newSanitaryUnit->assign($this->request->get());
            $newSanitaryUnit->DateCreateUser = Users::currentUser()->fname;
            $newSanitaryUnit->DateCreate = date("l, j F Y H:i:s");
            if($newSanitaryUnit->save()){
                $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                $_SESSION['CURRENT_MSG']  = "success";
                Router::redirect('setting/allSanitaryUnit');
            }else{
              $_SESSION['CURRENT_MSG_TEXT'] = $newSanitaryUnit->getErrorMessages();
              $_SESSION['CURRENT_MSG'] = "error";
            }
          }
        $this->view->newSanitaryUnit = $newSanitaryUnit;
        $this->view->allSanitaryUnit = SanitaryUnit::findAll();
        $this->view->allCountry = Country::getOptionsForForm();
        $this->view->allProvince = Province::getOptionsForForm();
        $this->view->allDistrict = District::getOptionsForForm();
        $this->view->displayErrors = $newSanitaryUnit->getErrorMessages();
        $this->view->render("config/sanitaryUnit");
    }

    public function editSanitaryUnitAction($id){
        $updateSanitaryUnit = SanitaryUnit::findById((int)$id);
        if($this->request->isPost()){
            $this->request->csrfCheck();
            $updateSanitaryUnit->assign($this->request->get());
            $updateSanitaryUnit->LastUpDateUser = Users::currentUser()->fname;
            $updateSanitaryUnit->LastUpDate = date("l, j F Y H:i:s");
            if($updateSanitaryUnit->save()){
                $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                $_SESSION['CURRENT_MSG']  = "success";
                Router::redirect('setting/allSanitaryUnit');
            }else{
              $_SESSION['CURRENT_MSG_TEXT'] = $updateSanitaryUnit->getErrorMessages();
              $_SESSION['CURRENT_MSG'] = "error";
            }
          }
        $this->view->updateSanitaryUnit = $updateSanitaryUnit;
        $this->view->displayErrors = $updateSanitaryUnit->getErrorMessages();
        $this->view->render("config/editSanitaryUnit");
    }

    public function deleteSanitaryUnitAction($id){
      $deleteSanitaryUnit= SanitaryUnit::findBYId((int)$id);
      if($deleteSanitaryUnit){
        $deleteSanitaryUnit->delete();
        $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
        $_SESSION['CURRENT_MSG']  = "success";
        Router::redirect('setting/allSanitaryUnit');
      }else {
              $_SESSION['CURRENT_MSG_TEXT'] = $deleteSanitaryUnit->getErrorMessages();
        $_SESSION['CURRENT_MSG'] = "error";
        Router::redirect('setting/allSanitaryUnit');
      }
  }
  
      /** Start Type_document */
      public function allType_documentAction(){
        $newType_document= new Type_document();
        if($this->request->isPost()){
            $this->request->csrfCheck();
            $newType_document->assign($this->request->get());
            $newType_document->DateCreateUser = Users::currentUser()->fname;
            $newType_document->DateCreate = date("l, j F Y H:i:s");
            if($newType_document->save()){
                $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                $_SESSION['CURRENT_MSG']  = "success";
                Router::redirect('setting/allType_document');
            }else{
              $_SESSION['CURRENT_MSG_TEXT'] = $newType_document->getErrorMessages();
              $_SESSION['CURRENT_MSG'] = "error";
            }
          }
        $this->view->newType_document = $newType_document;
        $this->view->allType_document = Type_document::findAll();
        $this->view->displayErrors = $newType_document->getErrorMessages();
        $this->view->render("config/Type_document");
    }

    public function editType_documentAction($id){
        $updateType_document = Type_document::findById((int)$id);
        if($this->request->isPost()){
            $this->request->csrfCheck();
            $updateType_document->assign($this->request->get());
            $updateType_document->LastUpDateUser = Users::currentUser()->fname;
            $updateType_document->LastUpDate = date("l, j F Y H:i:s");
            if($updateType_document->save()){
                $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                $_SESSION['CURRENT_MSG']  = "success";
                Router::redirect('setting/allType_document');
            }else{
              $_SESSION['CURRENT_MSG_TEXT'] = $updateType_document->getErrorMessages();
              $_SESSION['CURRENT_MSG'] = "error";
            }
          }
        $this->view->updateType_document = $updateType_document;
        $this->view->displayErrors = $updateType_document->getErrorMessages();
        $this->view->render("config/editType_document");
    }

    public function deleteType_documentAction($id){
      $deleteType_document= Type_document::findBYId((int)$id);
      if($deleteType_document){
        $deleteType_document->delete();
        $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
        $_SESSION['CURRENT_MSG']  = "success";
        Router::redirect('setting/allType_document');
      }else {
              $_SESSION['CURRENT_MSG_TEXT'] = $deleteType_document->getErrorMessages();
        $_SESSION['CURRENT_MSG'] = "error";
        Router::redirect('setting/allType_document');
      }
  }

  // Category Method

          public function allCategoryAction(){
            $newCategory = new Category();
            if($this->request->isPost()){
                $this->request->csrfCheck();
                $newCategory->assign($this->request->get());
                $newCategory->DateCreateUser = Users::currentUser()->fname;
                $newCategory->DateCreate = date("l, j F Y H:i:s");
                if($newCategory->save()){
                    $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                    $_SESSION['CURRENT_MSG']  = "success";
                    Router::redirect('setting/allCategory');
                }else{
                  $_SESSION['CURRENT_MSG'] = "error";
                  $_SESSION['CURRENT_MSG_TEXT'] = $newCategory->getErrorMessages();
                }
              }
            $this->view->newCategory = $newCategory;
            $this->view->allCategory = Category::findAll();
            $this->view->displayErrors = $newCategory->getErrorMessages();
            $this->view->render("config/Category");
        }

        public function editCategoryAction($id){
            $updateCategory = Category::findById((int)$id);
            if($this->request->isPost()){
                $this->request->csrfCheck();
                $updateCategory->assign($this->request->get());
                $updateCategory->LastUpDateUser = Users::currentUser()->fname;
                $updateCategory->LastUpDate = date("l, j F Y H:i:s");
                if($updateCategory->save()){
                    $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                    $_SESSION['CURRENT_MSG']  = "success";
                    Router::redirect('setting/allCategory');
                }else{
                  $_SESSION['CURRENT_MSG_TEXT'] = $updateCategory->getErrorMessages();
                  $_SESSION['CURRENT_MSG'] = "error";
                }
              }
            $this->view->updateCategory = $updateCategory;
            $this->view->displayErrors = $updateCategory->getErrorMessages();
            $this->view->render("config/editCategory");
        }

        public function deleteCategoryAction($id){
          $deleteCategory = Category::findBYId((int)$id);
          if($deleteCategory){
            $deleteCategory->LastUpDate = date("l, j F Y H:i:s");
            $deleteCategory->delete();
            $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
            $_SESSION['CURRENT_MSG']  = "success";
            Router::redirect('setting/allCategory');
          }else {
            $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
            $_SESSION['CURRENT_MSG'] = "error";
            Router::redirect('setting/allCategory');
          }
        }

            // Employment Method

          public function allEmploymentAction(){
            $newEmployment = new Employment();
            if($this->request->isPost()){
                $this->request->csrfCheck();
                $newEmployment->assign($this->request->get());
                $newEmployment->DateCreateUser = Users::currentUser()->fname;
                $newEmployment->DateCreate = date("l, j F Y H:i:s");
                if($newEmployment->save()){
                    $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                    $_SESSION['CURRENT_MSG']  = "success";
                    Router::redirect('setting/allEmployment');
                }else{
                  $_SESSION['CURRENT_MSG'] = "error";
                  $_SESSION['CURRENT_MSG_TEXT'] = $newEmployment->getErrorMessages();
                }
              }
            $this->view->newEmployment = $newEmployment;
            $this->view->allEmployment = Employment::findAll();
            $this->view->displayErrors = $newEmployment->getErrorMessages();
            $this->view->render("config/Employment");
        }

        public function editEmploymentAction($id){
            $updateEmployment = Employment::findById((int)$id);
            if($this->request->isPost()){
                $this->request->csrfCheck();
                $updateEmployment->assign($this->request->get());
                $updateEmployment->LastUpDateUser = Users::currentUser()->fname;
                $updateEmployment->LastUpDate = date("l, j F Y H:i:s");
                if($updateEmployment->save()){
                    $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                    $_SESSION['CURRENT_MSG']  = "success";
                    Router::redirect('setting/allEmployment');
                }else{
                  $_SESSION['CURRENT_MSG_TEXT'] = $updateEmployment->getErrorMessages();
                  $_SESSION['CURRENT_MSG'] = "error";
                }
              }
            $this->view->updateEmployment = $updateEmployment;
            $this->view->displayErrors = $updateEmployment->getErrorMessages();
            $this->view->render("config/editEmployment");
        }

        public function deleteEmploymentAction($id){
          $deleteEmployment = Employment::findBYId((int)$id);
          if($deleteEmployment){
            $deleteEmployment->LastUpDate = date("l, j F Y H:i:s");
            $deleteEmployment->delete();
            $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
            $_SESSION['CURRENT_MSG']  = "success";
            Router::redirect('setting/allEmployment');
          }else {
            $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
            $_SESSION['CURRENT_MSG'] = "error";
            Router::redirect('setting/allEmployment');
          }
    }

            // Instance Method

          public function allInstanceAction(){
            $newInstance = new Instance();
            if($this->request->isPost()){
                $this->request->csrfCheck();
                $newInstance->assign($this->request->get());
                $newInstance->DateCreateUser = Users::currentUser()->fname;
                $newInstance->DateCreate = date("l, j F Y H:i:s");
                if($newInstance->save()){
                    $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                    $_SESSION['CURRENT_MSG']  = "success";
                    Router::redirect('setting/allInstance');
                }else{
                  $_SESSION['CURRENT_MSG'] = "error";
                  $_SESSION['CURRENT_MSG_TEXT'] = $newInstance->getErrorMessages();
                }
              }
            $this->view->newInstance = $newInstance;
            $this->view->allInstance = Instance::findAll();
            $this->view->displayErrors = $newInstance->getErrorMessages();
            $this->view->render("config/Instance");
        }

        public function editInstanceAction($id){
            $updateInstance = Instance::findById((int)$id);
            if($this->request->isPost()){
                $this->request->csrfCheck();
                $updateInstance->assign($this->request->get());
                $updateInstance->LastUpDateUser = Users::currentUser()->fname;
                $updateInstance->LastUpDate = date("l, j F Y H:i:s");
                if($updateInstance->save()){
                    $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                    $_SESSION['CURRENT_MSG']  = "success";
                    Router::redirect('setting/allInstance');
                }else{
                  $_SESSION['CURRENT_MSG_TEXT'] = $updateInstance->getErrorMessages();
                  $_SESSION['CURRENT_MSG'] = "error";
                }
              }
            $this->view->updateInstance = $updateInstance;
            $this->view->displayErrors = $updateInstance->getErrorMessages();
            $this->view->render("config/editInstance");
        }

        public function deleteInstanceAction($id){
          $deleteInstance = Instance::findBYId((int)$id);
          if($deleteInstance){
            $deleteInstance->LastUpDate = date("l, j F Y H:i:s");
            $deleteInstance->delete();
            $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
            $_SESSION['CURRENT_MSG']  = "success";
            Router::redirect('setting/allInstance');
          }else {
            $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
            $_SESSION['CURRENT_MSG'] = "error";
            Router::redirect('setting/allInstance');
          }
    }

        // Cause Method

        public function allCauseAction(){
            $newCause = new Cause();
            if($this->request->isPost()){
                $this->request->csrfCheck();
                $newCause->assign($this->request->get());
                $newCause->DateCreateUser = Users::currentUser()->fname;
                $newCause->DateCreate = date("l, j F Y H:i:s");
                if($newCause->save()){
                    $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                    $_SESSION['CURRENT_MSG']  = "success";
                    Router::redirect('setting/allCause');
                }else{
                  $_SESSION['CURRENT_MSG'] = "error";
                  $_SESSION['CURRENT_MSG_TEXT'] = $newCause->getErrorMessages();
                }
              }
            $this->view->newCause = $newCause;
            $this->view->allCause = Cause::findAll();
            $this->view->displayErrors = $newCause->getErrorMessages();
            $this->view->render("config/Cause");
        }

        public function editCauseAction($id){
            $updateCause = Cause::findById((int)$id);
            if($this->request->isPost()){
                $this->request->csrfCheck();
                $updateCause->assign($this->request->get());
                $updateCause->LastUpDateUser = Users::currentUser()->fname;
                $updateCause->LastUpDate = date("l, j F Y H:i:s");
                if($updateCause->save()){
                    $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                    $_SESSION['CURRENT_MSG']  = "success";
                    Router::redirect('setting/allCause');
                }else{
                  $_SESSION['CURRENT_MSG_TEXT'] = $updateCause->getErrorMessages();
                  $_SESSION['CURRENT_MSG'] = "error";
                }
              }
            $this->view->updateCause = $updateCause;
            $this->view->displayErrors = $updateCause->getErrorMessages();
            $this->view->render("config/editCause");
        }

        public function deleteCauseAction($id){
          $deleteCause = Cause::findBYId((int)$id);
          if($deleteCause){
            $deleteCause->LastUpDate = date("l, j F Y H:i:s");
            $deleteCause->delete();
            $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
            $_SESSION['CURRENT_MSG']  = "success";
            Router::redirect('setting/allCause');
          }else {
            $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
            $_SESSION['CURRENT_MSG'] = "error";
            Router::redirect('setting/allCause');
          }
    }

            // CauseType Method

          public function allCauseTypeAction(){
            $newCauseType = new CauseType();
            if($this->request->isPost()){
                $this->request->csrfCheck();
                $newCauseType->assign($this->request->get());
                $newCauseType->DateCreateUser = Users::currentUser()->fname;
                $newCauseType->DateCreate = date("l, j F Y H:i:s");
                if($newCauseType->save()){
                    $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                    $_SESSION['CURRENT_MSG']  = "success";
                    Router::redirect('setting/allCauseType');
                }else{
                  $_SESSION['CURRENT_MSG'] = "error";
                  $_SESSION['CURRENT_MSG_TEXT'] = $newCauseType->getErrorMessages();
                }
              }
            $this->view->newCauseType = $newCauseType;
            $this->view->allCauseType = CauseType::findAll();
            $this->view->displayErrors = $newCauseType->getErrorMessages();
            $this->view->render("config/CauseType");
        }

        public function editCauseTypeAction($id){
            $updateCauseType = CauseType::findById((int)$id);
            if($this->request->isPost()){
                $this->request->csrfCheck();
                $updateCauseType->assign($this->request->get());
                $updateCauseType->LastUpDateUser = Users::currentUser()->fname;
                $updateCauseType->LastUpDate = date("l, j F Y H:i:s");
                if($updateCauseType->save()){
                    $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                    $_SESSION['CURRENT_MSG']  = "success";
                    Router::redirect('setting/allCauseType');
                }else{
                  $_SESSION['CURRENT_MSG_TEXT'] = $updateCauseType->getErrorMessages();
                  $_SESSION['CURRENT_MSG'] = "error";
                }
              }
            $this->view->updateCauseType = $updateCauseType;
            $this->view->displayErrors = $updateCauseType->getErrorMessages();
            $this->view->render("config/editCauseType");
        }

        public function deleteCauseTypeAction($id){
          $deleteCauseType = CauseType::findBYId((int)$id);
          if($deleteCauseType){
            $deleteCauseType->LastUpDate = date("l, j F Y H:i:s");
            $deleteCauseType->delete();
            $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
            $_SESSION['CURRENT_MSG']  = "success";
            Router::redirect('setting/allCauseType');
          }else {
            $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
            $_SESSION['CURRENT_MSG'] = "error";
            Router::redirect('setting/allCauseType');
          }
    }
            // Intervention Method

          public function allInterventionAction(){
            $newIntervention = new Intervention();
            if($this->request->isPost()){
                $this->request->csrfCheck();
                $newIntervention->assign($this->request->get());
                $newIntervention->DateCreateUser = Users::currentUser()->fname;
                $newIntervention->DateCreate = date("l, j F Y H:i:s");
                if($newIntervention->save()){
                    $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                    $_SESSION['CURRENT_MSG']  = "success";
                    Router::redirect('setting/allIntervention');
                }else{
                  $_SESSION['CURRENT_MSG'] = "error";
                  $_SESSION['CURRENT_MSG_TEXT'] = $newIntervention->getErrorMessages();
                }
              }
            $this->view->newIntervention = $newIntervention;
            $this->view->allIntervention = Intervention::findAll();
            $this->view->displayErrors = $newIntervention->getErrorMessages();
            $this->view->render("config/Intervention");
        }

        public function editInterventionAction($id){
            $updateIntervention = Intervention::findById((int)$id);
            if($this->request->isPost()){
                $this->request->csrfCheck();
                $updateIntervention->assign($this->request->get());
                $updateIntervention->LastUpDateUser = Users::currentUser()->fname;
                $updateIntervention->LastUpDate = date("l, j F Y H:i:s");
                if($updateIntervention->save()){
                    $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                    $_SESSION['CURRENT_MSG']  = "success";
                    Router::redirect('setting/allIntervention');
                }else{
                  $_SESSION['CURRENT_MSG_TEXT'] = $updateIntervention->getErrorMessages();
                  $_SESSION['CURRENT_MSG'] = "error";
                }
              }
            $this->view->updateIntervention = $updateIntervention;
            $this->view->displayErrors = $updateIntervention->getErrorMessages();
            $this->view->render("config/editIntervention");
        }

        public function deleteInterventionAction($id){
          $deleteIntervention = Intervention::findBYId((int)$id);
          if($deleteIntervention){
            $deleteIntervention->LastUpDate = date("l, j F Y H:i:s");
            $deleteIntervention->delete();
            $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
            $_SESSION['CURRENT_MSG']  = "success";
            Router::redirect('setting/allIntervention');
          }else {
            $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
            $_SESSION['CURRENT_MSG'] = "error";
            Router::redirect('setting/allIntervention');
          }
    }
}