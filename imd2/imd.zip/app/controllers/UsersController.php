<?php
    namespace App\Controllers;
    use Core\Controller;
    use Core\Router;
    use App\Models\District;
    use App\Models\Country;
    use App\Models\Area;
    use App\Models\Criterion_evaluation;
    use App\Models\Category;
    use App\Models\Cause;
    use App\Models\Employment;
    use App\Models\Province;
    use App\Models\Area_padrao;
    use App\Models\EvaluationType;
    use App\Models\Type_document;
    use App\Models\Users;
    use App\Models\MeansVerification;
    use App\Models\SanitaryUnit;
    use App\Lib\Utilities\Uploads;
    use Core\Session;
    use Core\H;

    /**
     * User of system
     */
    class UsersController extends Controller {
    	
    	public function onConstruct(){
    		$this->view->setLayout(LAYOUT_ADMIN);
    	}

    	public function allUsersAction(){
    		$newUsers = new Users();
    		if($this->request->isPost()){
                $this->request->csrfCheck();
                $newUsers->assign($this->request->get());
                $newUsers->DateCreateUser = Users::currentUser()->fname;
                $newUsers->DateCreate = date("l, j F Y H:i:s");
                if($newUsers->save()){
                    $_SESSION['CURRENT_MSG_TEXT']  = "Dados salvos com sucesso";
                    $_SESSION['CURRENT_MSG']  = "success";
                    Router::redirect('setting/allCountry');
                }else{
                  $_SESSION['CURRENT_MSG'] = "error";
                  $_SESSION['CURRENT_MSG_TEXT'] = $newUsers->getErrorMessages();
                }
              }
            $this->view->newUsers = $newUsers;
            $this->view->allUsers = Users::findAll();
            $this->view->displayErrors = $newUsers->getErrorMessages();
            $this->view->render("users/allUsers");
    	}
    }