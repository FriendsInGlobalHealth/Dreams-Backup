<?php
  namespace App\Controllers;
  use Core\Controller;
  use Core\Router;
  use App\Models\Users;
  use Core\H;
  use Core\Session;

  class DashboardController extends Controller {

    public function onConstruct(){
      $this->view->setLayout(LAYOUT_ADMIN);
    }

    public function indexAction() {
      $this->view->render('home/index');
    }
  }
