Para configurar a conexao com:
1 -Configurações - Config/config.php
2- Controlladores - App/Controller
3- Modelos - App/Models
4- Views - App/Views
5- Core - Core/