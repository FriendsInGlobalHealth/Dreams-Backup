<?php 
namespace Core;
use Core\session;

class Alert {
      /**
   * Creates a styled list of form errors used to display on front-end to user.
   * @method displayAlert
   * @param  array         $errors pass in the form errors ['field'=>'message']
   * @return string                return html string with styled form errors.
   */
  public static function displayAlert($type,$msg) {
      $html ='<div class="alert wow fadeInRight alert-'.$type.' alert-dismissible" wow-data-duration="2s">';
      $html .='<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>';
                if($type == "success"){
                            $html .= '<li class="py-1">'.$msg.'</li>';
                }else{
                  foreach($msg as $field => $error) {
                    $html .= '<li class="py-1">'.$error.'</li><br>';
                  }
                }
      $html .='</div>';

    return $html;
  }

}
