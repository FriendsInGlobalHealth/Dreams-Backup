-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 10-Jul-2019 às 20:11
-- Versão do servidor: 10.1.35-MariaDB
-- versão do PHP: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `app_vbg3`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `DateCreated` varchar(45) DEFAULT NULL,
  `DateCreateUser` varchar(150) DEFAULT NULL,
  `LastUpDate` varchar(45) DEFAULT NULL,
  `LastUpDateUser` varchar(150) DEFAULT NULL,
  `deleted` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `category`
--

INSERT INTO `category` (`id`, `name`, `status`, `DateCreated`, `DateCreateUser`, `LastUpDate`, `LastUpDateUser`, `deleted`) VALUES
(1, 'Psic&oacute;logo', 'Activo', NULL, 'Jhpiego', NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `country`
--

CREATE TABLE `country` (
  `id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  `DateCreate` varchar(45) DEFAULT NULL,
  `DateCreateUser` varchar(45) DEFAULT NULL,
  `LastUpDate` varchar(45) DEFAULT NULL,
  `LastUpDateUser` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `country`
--

INSERT INTO `country` (`id`, `name`, `status`, `deleted`, `DateCreate`, `DateCreateUser`, `LastUpDate`, `LastUpDateUser`) VALUES
(1, 'Moçambique', 'Activo', 0, 'Friday, 28 June 2019 08:07:07', 'Jhpiego', '2019-06-19 02:19:13', NULL),
(2, 'Brasil', 'Activo', 0, NULL, 'Jhpiego', '2019-06-19 02:19:13', NULL),
(3, 'Estado', 'Activo', 0, NULL, 'Jhpiego', '2019-06-19 14:51:46', NULL),
(4, 'Zambia', 'Activo', 0, NULL, 'Jhpiego', '2019-06-19 14:51:46', NULL),
(5, 'África do Sul', 'Activo', 0, NULL, 'Jhpiego', '2019-06-19 14:51:46', NULL),
(6, 'Angola', 'Activo', 0, NULL, 'Jhpiego', '2019-06-19 14:51:46', NULL),
(7, 'Guiné Bissaus', 'Activo', 0, NULL, 'Jhpiego', '2019-06-19 14:51:46', NULL),
(8, 'Portugal', 'Activo', 0, NULL, 'Jhpiego', '2019-06-19 14:51:46', NULL),
(9, 'Inglaterra', 'Activo', 0, NULL, 'Jhpiego', '2019-06-19 14:51:46', NULL),
(11, 'Japão', 'Activo', 0, NULL, 'Jhpiego', '2019-06-19 14:51:46', NULL),
(12, 'Chile', 'Activo', 0, 'Friday, 28 June 2019 09:09:08', 'Jhpiego', 'Friday, 28 June 2019 09:13:00', 'Jhpiego'),
(13, 'Alemanha', 'Activo', 0, 'Saturday, 29 June 2019 13:44:45', 'Jhpiego', NULL, NULL),
(14, 'N&atilde;o Listado', 'Activo', 0, 'Tuesday, 9 July 2019 11:56:44', 'Jhpiego', NULL, NULL),
(15, 'M&eacute;xico', 'Activo', 0, 'Tuesday, 9 July 2019 11:57:07', 'Jhpiego', NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `migrations`
--

CREATE TABLE `migrations` (
  `id` int(11) NOT NULL,
  `migration` varchar(35) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `migrations`
--

INSERT INTO `migrations` (`id`, `migration`) VALUES
(1, 'Migration1549756212'),
(2, 'Migration1549770647'),
(3, 'Migration1561627434'),
(14, 'Migration1561627614'),
(15, 'Migration1561627699'),
(16, 'Migration1561715872'),
(7, 'Migration1561716378'),
(17, 'Migration1561716475'),
(13, 'Migration1561716633'),
(12, 'Migration1561720082'),
(19, 'Migration1561733197'),
(18, 'Migration1561794750'),
(20, 'Migration1561802876'),
(21, 'Migration1561803801'),
(22, 'Migration1561805508');

-- --------------------------------------------------------

--
-- Estrutura da tabela `sa_administrative_post`
--

CREATE TABLE `sa_administrative_post` (
  `id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `district_id` int(11) DEFAULT NULL,
  `province_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  `DateCreate` varchar(45) DEFAULT NULL,
  `DateCreateUser` varchar(45) DEFAULT NULL,
  `LastUpDate` varchar(45) DEFAULT NULL,
  `LastUpDateUser` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `sa_administrative_post`
--

INSERT INTO `sa_administrative_post` (`id`, `name`, `district_id`, `province_id`, `country_id`, `status`, `deleted`, `DateCreate`, `DateCreateUser`, `LastUpDate`, `LastUpDateUser`) VALUES
(1, 'Varrela', 2, 1, 1, 'Activo', 0, 'Thursday, 4 July 2019 17:41:15', 'Jhpiego', 'Friday, 5 July 2019 00:30:30', 'Jhpiego'),
(2, 'N&atilde;o Listado', 5, 19, 1, 'Activo', 0, 'Saturday, 6 July 2019 03:09:45', 'Jhpiego', NULL, NULL),
(3, 'Alto Molócue', 5, 19, 1, 'Activo', 0, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `sa_area`
--

CREATE TABLE `sa_area` (
  `id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  `DateCreate` varchar(45) DEFAULT NULL,
  `DateCreateUser` varchar(45) DEFAULT NULL,
  `LastUpDate` varchar(45) DEFAULT NULL,
  `LastUpDateUser` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `sa_area`
--

INSERT INTO `sa_area` (`id`, `name`, `status`, `deleted`, `DateCreate`, `DateCreateUser`, `LastUpDate`, `LastUpDateUser`) VALUES
(1, 'I. Disponibilidade de cuidados p&oacute;s VBG', 'Activo', 0, 'Friday, 28 June 2019 13:27:16', 'Jhpiego', 'Friday, 28 June 2019 13:39:40', 'Jhpiego'),
(2, 'II. Mat&eacute;rias e Infraestruturas', 'Activo', 0, 'Friday, 28 June 2019 13:28:59', 'Jhpiego', NULL, NULL),
(3, 'III. Identifica&ccedil;&atilde;o Precoce de V&iacute;timas de Viol&ecirc;ncia', 'Activo', 0, 'Friday, 28 June 2019 13:29:17', 'Jhpiego', NULL, NULL),
(4, 'IV. Cuidados Cl&iacute;nicos Centrados no Utente', 'Activo', 0, 'Friday, 28 June 2019 13:29:33', 'Jhpiego', NULL, NULL),
(5, 'V. Medicina Legal', 'Activo', 0, 'Friday, 28 June 2019 13:29:55', 'Jhpiego', 'Tuesday, 2 July 2019 13:59:27', 'Jhpiego'),
(6, 'VI. Sistema de Refer&ecirc;ncia e Seguimento da V&iacute;tima', 'Activo', 0, 'Friday, 28 June 2019 13:30:08', 'Jhpiego', NULL, NULL),
(7, 'VII. Forma&ccedil;&atilde;o e Melhoria de Qualidade', 'Activo', 0, 'Friday, 28 June 2019 13:30:22', 'Jhpiego', NULL, NULL),
(8, 'VIII. Pol&iacute;ticas de Cuidados de Sa&uacute;de', 'Activo', 0, 'Friday, 28 June 2019 13:30:41', 'Jhpiego', NULL, NULL),
(9, 'IX. Cria&ccedil;&atilde;o de Demanda Para Uso de Cuidados P&oacute;s Viol&ecirc;ncia', 'Activo', 0, 'Friday, 28 June 2019 13:32:16', 'Jhpiego', NULL, NULL),
(10, 'X. Reporte e Sistemas de Informa&ccedil;&atilde;o', 'Activo', 0, 'Friday, 28 June 2019 13:32:31', 'Jhpiego', NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `sa_area_padrao`
--

CREATE TABLE `sa_area_padrao` (
  `id` int(11) NOT NULL,
  `area_id` int(11) DEFAULT NULL,
  `name` text,
  `status` varchar(10) DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  `DateCreate` varchar(45) DEFAULT NULL,
  `DateCreateUser` varchar(45) DEFAULT NULL,
  `LastUpDate` varchar(45) DEFAULT NULL,
  `LastUpDateUser` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `sa_area_padrao`
--

INSERT INTO `sa_area_padrao` (`id`, `area_id`, `name`, `status`, `deleted`, `DateCreate`, `DateCreateUser`, `LastUpDate`, `LastUpDateUser`) VALUES
(1, 1, 'A US oferece cuidados acess&iacute;veis e gratuitos &aacute;s v&iacute;timas de viol&ecirc;ncia', 'Activo', 0, 'Friday, 28 June 2019 14:06:19', 'Jhpiego', 'Saturday, 29 June 2019 20:09:53', 'Jhpiego'),
(2, 2, 'A US tem materiais de IEC GBV &nbsp;', 'Activo', 0, 'Friday, 28 June 2019 14:10:30', 'Jhpiego', NULL, NULL),
(3, 2, 'A US tem infraestruturas equipamentos e materiais adequados para providenciar cuidados p&oacute;s viol&ecirc;ncia (Veja detalhes na Caixa 1)', 'Activo', 0, 'Friday, 28 June 2019 14:11:18', 'Jhpiego', NULL, NULL),
(4, 3, 'A US identifica precocemente utentes que tenham sido v&iacute;timas de viol&ecirc;ncia', 'Activo', 0, 'Friday, 28 June 2019 14:12:14', 'Jhpiego', 'Saturday, 29 June 2019 19:54:28', 'Jhpiego'),
(5, 3, 'O Provedor faz perguntas sobre VPI de forma apropriada', 'Activo', 0, 'Friday, 28 June 2019 14:12:44', 'Jhpiego', 'Saturday, 29 June 2019 19:54:35', 'Jhpiego'),
(6, 3, 'O provedor avalia o risco imediato que os utentes podem ter no momento da revela&ccedil;&atilde;o', 'Activo', 0, 'Friday, 28 June 2019 14:13:32', 'Jhpiego', 'Saturday, 29 June 2019 19:54:41', 'Jhpiego'),
(7, 4, 'O Provedor obt&eacute;m consentimento informado para exame f&iacute;sico', 'Activo', 0, 'Friday, 28 June 2019 14:14:07', 'Jhpiego', 'Monday, 1 July 2019 18:36:22', 'Jhpiego'),
(8, 4, 'Provedor de sa&uacute;de realiza o tratamento das les&otilde;es', 'Activo', 0, 'Friday, 28 June 2019 14:15:43', 'Jhpiego', 'Saturday, 29 June 2019 19:55:36', 'Jhpiego'),
(9, 4, 'O provedor demonstra conhecimento em aconselhamento de crise para evitar revitimiza&ccedil;&atilde;o', 'Activo', 0, 'Friday, 28 June 2019 14:17:01', 'Jhpiego', 'Saturday, 29 June 2019 19:55:44', 'Jhpiego'),
(10, 4, 'O provedor p&otilde;e em pr&aacute;tica as orienta&ccedil;&otilde;es para atendimento &aacute;s crian&ccedil;as e adolescentes v&iacute;timas de v', 'Activo', 0, 'Friday, 28 June 2019 14:18:58', 'Jhpiego', 'Saturday, 29 June 2019 19:55:50', 'Jhpiego'),
(11, 4, 'Provedor respeita e mant&eacute;m a privacidade e confidencialidade do utente', 'Activo', 0, 'Friday, 28 June 2019 14:19:43', 'Jhpiego', 'Saturday, 29 June 2019 19:56:00', 'Jhpiego'),
(12, 4, 'O provedor oferece atendimento humanizado e respeitoso para evitar revitimiza&ccedil;&atilde;o', 'Activo', 0, 'Friday, 28 June 2019 14:20:22', 'Jhpiego', 'Monday, 1 July 2019 15:26:48', 'Jhpiego'),
(13, 4, 'Provedor realiza exame das les&otilde;es extra-genitais e genito-anais', 'Activo', 0, 'Friday, 28 June 2019 14:23:25', 'Jhpiego', 'Monday, 1 July 2019 18:47:33', 'Jhpiego'),
(14, 4, 'A US oferece contracep&ccedil;&atilde;o de emerg&ecirc;ncia para v&iacute;timas de viol&ecirc;ncia sexual do sexo feminino de acordo com o protocolo', 'Activo', 0, 'Friday, 28 June 2019 14:23:47', 'Jhpiego', 'Monday, 1 July 2019 20:49:45', 'Jhpiego'),
(15, 4, 'O provedor oferece &aacute;s v&iacute;timas de viol&ecirc;ncia aconselhamento e testagem para HIV e profilaxia p&oacute;s exposi&ccedil;&atilde;o para HIV (PPE) dentro de 72 Horas depois da viol&ecirc;ncia sexual.', 'Activo', 0, 'Friday, 28 June 2019 14:24:59', 'Jhpiego', 'Monday, 1 July 2019 20:50:48', 'Jhpiego'),
(16, 5, 'O provedor realiza o exame m&eacute;dico-legal de acordo com as recomenda&ccedil;&otilde;es nacionais', 'Activo', 0, 'Friday, 28 June 2019 14:28:24', 'Jhpiego', 'Monday, 1 July 2019 15:29:55', 'Jhpiego'),
(17, 4, 'O provedor oferece medica&ccedil;&otilde;es relevantes para preven&ccedil;&atilde;o ou tratamento de infec&ccedil;&otilde;es de transmiss&atilde;o', 'Activo', 0, 'Friday, 28 June 2019 14:29:57', 'Jhpiego', 'Monday, 1 July 2019 15:29:40', 'Jhpiego'),
(18, 4, 'O provedor oferece assist&ecirc;ncia psicol&oacute;gica aos utentes v&iacute;timas de viol&ecirc;ncia sexual', 'Activo', 0, 'Friday, 28 June 2019 14:31:04', 'Jhpiego', 'Monday, 1 July 2019 15:29:47', 'Jhpiego'),
(19, 5, 'O provedor colecta, armazena e / ou transporta evid&ecirc;ncias forenses de forma segura de acordo com protocolo nacional', 'Activo', 0, 'Friday, 28 June 2019 14:46:00', 'Jhpiego', 'Monday, 1 July 2019 15:30:02', 'Jhpiego'),
(20, 6, 'A US tem sistema de refer&ecirc;ncia para facilitar a utiliza&ccedil;&atilde;o dos servi&ccedil;os necess&aacute;rios na rede de apoio &aacute; v&iacute;tima de viol&ecirc;ncia', 'Activo', 0, 'Friday, 28 June 2019 14:47:31', 'Jhpiego', 'Monday, 1 July 2019 15:30:50', 'Jhpiego'),
(21, 6, 'Os provedores oferecem servi&ccedil;os de seguimento da v&iacute;tima de viol&ecirc;ncia', 'Activo', 0, 'Friday, 28 June 2019 14:49:48', 'Jhpiego', 'Monday, 1 July 2019 15:30:59', 'Jhpiego'),
(22, 7, 'Todos provedores que oferecem servi&ccedil;os p&oacute;s VBG foram treinados para exercerem seus pap&eacute;is e responsabilidades no cuidado com os utentes', 'Activo', 0, 'Friday, 28 June 2019 14:54:35', 'Jhpiego', 'Monday, 1 July 2019 15:31:07', 'Jhpiego'),
(23, 7, 'A US tem um Sistema de melhoria continua de qualidade de cuidados p&oacute;s VBG', 'Activo', 0, 'Friday, 28 June 2019 14:55:18', 'Jhpiego', 'Monday, 1 July 2019 15:31:14', 'Jhpiego'),
(24, 8, 'A US tem protocolos para oferecer cuidados p&oacute;s viol&ecirc;ncia de acordo com as recomenda&ccedil;&otilde;es nacionais', 'Activo', 0, 'Friday, 28 June 2019 14:56:06', 'Jhpiego', 'Monday, 1 July 2019 15:31:23', 'Jhpiego'),
(25, 9, 'A US apoia a divulga&ccedil;&atilde;o dos servi&ccedil;os e aumento de consci&ecirc;ncia de uso de cuidados', 'Activo', 0, 'Friday, 28 June 2019 14:57:13', 'Jhpiego', 'Monday, 1 July 2019 15:31:34', 'Jhpiego'),
(26, 10, 'A US possui fichas de notifica&ccedil;&atilde;o, livros de registo e outros instrumentos de recolha de dados dos cuidados p&oacute;s VBG', 'Activo', 0, 'Friday, 28 June 2019 14:58:12', 'Jhpiego', 'Monday, 1 July 2019 15:31:40', 'Jhpiego'),
(27, 10, 'A US tem um Sistema de avalia&ccedil;&atilde;o e monitoria de dados VBG', 'Activo', 0, 'Friday, 28 June 2019 14:58:48', 'Jhpiego', 'Monday, 1 July 2019 15:31:48', 'Jhpiego'),
(28, 10, 'Os dados de VBG s&atilde;o analisados para melhorar a presta&ccedil;&atilde;o de servi&ccedil;os oferecidos e sistemas de resposta &aacute; VBG', 'Activo', 0, 'Friday, 28 June 2019 14:59:48', 'Jhpiego', 'Monday, 1 July 2019 15:31:56', 'Jhpiego');

-- --------------------------------------------------------

--
-- Estrutura da tabela `sa_bairro`
--

CREATE TABLE `sa_bairro` (
  `id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `Latitude_N` varchar(150) DEFAULT NULL,
  `Longitude_E` varchar(150) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `province_id` int(11) DEFAULT NULL,
  `district_id` int(11) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  `DateCreate` varchar(45) DEFAULT NULL,
  `DateCreateUser` varchar(45) DEFAULT NULL,
  `LastUpDate` varchar(45) DEFAULT NULL,
  `LastUpDateUser` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `sa_category`
--

CREATE TABLE `sa_category` (
  `id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  `DateCreate` varchar(45) DEFAULT NULL,
  `DateCreateUser` varchar(45) DEFAULT NULL,
  `LastUpDate` varchar(45) DEFAULT NULL,
  `LastUpDateUser` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `sa_cause`
--

CREATE TABLE `sa_cause` (
  `id` int(11) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `DateCreate` varchar(45) DEFAULT NULL,
  `DateCreateUser` varchar(150) DEFAULT NULL,
  `LastUpDate` varchar(45) DEFAULT NULL,
  `LastUpDateUser` varchar(150) DEFAULT NULL,
  `deleted` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `sa_cause`
--

INSERT INTO `sa_cause` (`id`, `name`, `status`, `DateCreate`, `DateCreateUser`, `LastUpDate`, `LastUpDateUser`, `deleted`) VALUES
(1, 'Falta de Recursos', 'Activo', NULL, 'Jhpiego', NULL, NULL, 0),
(2, 'Falta de Forma&ccedil;&atilde;o', 'Activo', 'Wednesday, 10 July 2019 16:57:10', 'Jhpiego', 'Wednesday, 10 July 2019 17:00:26', 'Jhpiego', 0),
(3, 'Falta de protocolo padronizado', 'Activo', 'Wednesday, 10 July 2019 16:58:05', 'Jhpiego', NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `sa_cause_type`
--

CREATE TABLE `sa_cause_type` (
  `id` int(11) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `cause_id` int(11) DEFAULT NULL,
  `order_intervention` text,
  `status` varchar(10) DEFAULT NULL,
  `DateCreated` varchar(45) DEFAULT NULL,
  `DateCreateUser` varchar(150) DEFAULT NULL,
  `LastUpDate` varchar(45) DEFAULT NULL,
  `LastUpDateUser` varchar(150) DEFAULT NULL,
  `deleted` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `sa_cause_type`
--

INSERT INTO `sa_cause_type` (`id`, `name`, `cause_id`, `order_intervention`, `status`, `DateCreated`, `DateCreateUser`, `LastUpDate`, `LastUpDateUser`, `deleted`) VALUES
(1, 'Financeiro', 1, '1.1', 'Activo', NULL, 'Jhpiego', 'Wednesday, 10 July 2019 19:56:13', 'Jhpiego', 0),
(2, 'Humanos', 1, '1.2', 'Activo', NULL, 'Jhpiego', NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `sa_criterion_evaluation`
--

CREATE TABLE `sa_criterion_evaluation` (
  `id` int(11) NOT NULL,
  `area_id` int(11) DEFAULT NULL,
  `area_padrao_id` int(11) DEFAULT NULL,
  `name` text,
  `means_verification` varchar(45) DEFAULT NULL,
  `description` text,
  `control` int(1) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  `DateCreate` varchar(45) DEFAULT NULL,
  `DateCreateUser` varchar(45) DEFAULT NULL,
  `LastUpDate` varchar(45) DEFAULT NULL,
  `LastUpDateUser` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `sa_criterion_evaluation`
--

INSERT INTO `sa_criterion_evaluation` (`id`, `area_id`, `area_padrao_id`, `name`, `means_verification`, `description`, `control`, `status`, `deleted`, `DateCreate`, `DateCreateUser`, `LastUpDate`, `LastUpDateUser`) VALUES
(1, 1, 1, 'A US oferece cuidados p&oacute;s viol&ecirc;ncia 24 horas por dia OU apoia ao utente a ter cuidados de refer&ecirc;ncia em outras US que oferecem cuidados 24 horas', 'E', NULL, 1, 'Activo', 0, 'Friday, 28 June 2019 16:40:35', 'Jhpiego', 'Thursday, 4 July 2019 13:10:56', 'Jhpiego'),
(2, 1, 1, 'A US n&atilde;o condiciona a oferta de cuidados ao reporte &aacute; policia.', 'E, R', NULL, 1, 'Activo', 0, 'Friday, 28 June 2019 16:41:24', 'Jhpiego', 'Saturday, 29 June 2019 20:55:41', 'Jhpiego'),
(3, 1, 1, 'A US tem todas guias de refer&ecirc;ncia inclusive para policia para que a v&iacute;tima n&atilde;o tenha que ir a policia para ter as guias de refer&ecirc;ncia', 'E, R', NULL, 1, 'Activo', 0, 'Friday, 28 June 2019 16:42:27', 'Jhpiego', 'Monday, 1 July 2019 16:01:56', 'Jhpiego'),
(4, 1, 1, 'A US garante privacidade durante o atendimento', 'E, D', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 15:34:50', 'Jhpiego', NULL, NULL),
(5, 1, 1, 'A US oferece cuidados gratuitos para v&iacute;timas de viol&ecirc;ncia', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 15:42:35', 'Jhpiego', NULL, NULL),
(6, 1, 1, 'A US prioriza as v&iacute;timas de viol&ecirc;ncia sexual para garantir que estas recebam os cuidados mais r&aacute;pido poss&iacute;vel', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 15:44:19', 'Jhpiego', NULL, NULL),
(7, 1, 1, 'A US garante que todos utentes tenham acesso aos cuidados independentemente do sexo, orienta&ccedil;ao sexual, ra&ccedil;a , religi&atilde;o, idade, estado marital etc.', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 15:45:07', 'Jhpiego', 'Monday, 1 July 2019 16:02:59', 'Jhpiego'),
(8, 2, 2, 'A US tem materiais IEC visiveis dirigidos aos utentes sobre VBG  (e.g.,posters , plafletos, leis , Direitos e &aacute;reas de alto trafego de utentes (Corredores, farm&aacute;cia, consultas etc.)', 'D, R', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 15:46:02', 'Jhpiego', 'Monday, 1 July 2019 16:01:03', 'Jhpiego'),
(9, 2, 3, 'A oferta de servi&ccedil;os VBG ocorre dentro  ou perto de  uma US e', '', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 15:48:46', 'Jhpiego', 'Monday, 1 July 2019 15:51:34', 'Jhpiego'),
(10, 2, 3, 'A US usa letreiros e sinais discretos para aumentar a seguran&ccedil;a e privacidade para utentes e provedores', '', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 15:52:29', 'Jhpiego', NULL, NULL),
(11, 2, 3, 'O local de atendimento t&ecirc;m privacidade (a vitima ou o provedor n&atilde;o podem ser ouvidas ou vistas durante o atendimento ) e est&aacute;  limpo, ventilado e iluminado.', '', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 15:52:53', 'Jhpiego', 'Monday, 1 July 2019 16:00:10', 'Jhpiego'),
(12, 2, 3, 'A US tem um local com privacidade para internamento de curta dura&ccedil;&atilde;o caso a v&iacute;tima necessite', '', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 15:53:18', 'Jhpiego', NULL, NULL),
(13, 2, 3, 'A US tem equipamentos essencias (Infraestruturas, mobili&aacute;rio, documentos) dispon&iacute;veis (Ver na Caixa 1)', '', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 15:56:46', 'Jhpiego', 'Monday, 1 July 2019 15:58:03', 'Jhpiego'),
(14, 2, 3, 'A US tem medicamentos basicos, vacinas e testes r&aacute;pidos dentro do prazo para responder a casos de viol&ecirc;ncia', '', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 16:05:55', 'Jhpiego', NULL, NULL),
(15, 2, 3, 'A US integra a gest&atilde;o de medicamentos necess&aacute;rios para responder a viol&ecirc;ncia na cadeia de distribui&ccedil;&atilde;o de medicamentos.', '', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 16:06:39', 'Jhpiego', NULL, NULL),
(16, 2, 3, 'A US tem stock pelo menos 3 meses  de medicamentos e consum&iacute;veis para responder a casos de viol&ecirc;ncia  (VEJA CAIXA 1 se algum artigo estiver em falta este crit&eacute;rio &eacute; N&Atilde;O).', '', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 16:07:19', 'Jhpiego', NULL, NULL),
(17, 3, 4, 'O provedor pergunta sobre viol&ecirc;ncia aos utentes que tenham sinais e sintomas de viol&ecirc;ncia (Veja Caixa 2)', 'E, R', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 16:09:23', 'Jhpiego', 'Monday, 1 July 2019 16:11:10', 'Jhpiego'),
(18, 3, 4, 'AUS tem um algor&iacute;tmo de rastreio de viol&ecirc;ncia alinhada com as normas nacionais ou da OMS', 'E, R', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 16:10:52', 'Jhpiego', NULL, NULL),
(19, 3, 4, 'US realiza rastreio cl&iacute;nico de VBG quando tem servi&ccedil;os dispon&iacute;veis:\r\n(op&ccedil;&otilde;es a presentar)\r\nSe estes crit&eacute;rios n&atilde;o estiverem observados os cuidados VBG s&atilde;o inadequados e n&atilde;o deve ser realizado o rastreio de VBG . Os provedores n&atilde;o devem fazer rastreio de universal .', 'E, R', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 16:14:43', 'Jhpiego', NULL, NULL),
(20, 3, 4, 'Provedores realizam rastreio clinico em portas de entrada espec&iacute;ficas (CPN , ATS, PF, PTV, SAAJ apartir dos 15 anos  etc.) Se os crit&eacute;rios minimos forem observados', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 16:15:10', 'Jhpiego', NULL, NULL),
(21, 3, 5, 'O provedor nunca pergunta sobre viol&ecirc;ncia  quando o utente esta acompanhado pelo parceiro ou pessoas da fam&iacute;lia', 'E, D', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 16:17:37', 'Jhpiego', NULL, NULL),
(22, 3, 5, 'O provedor aflora o topico sobre VBG com introdu&ccedil;&atilde;o aberta antes de fazer perguntas directamente.', 'E, D', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 16:18:54', 'Jhpiego', NULL, NULL),
(23, 3, 5, 'O provedor n&atilde;o for&ccedil;a o rastreio para utentes que n&atilde;o querem ser rastreados', 'E, D', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 16:19:28', 'Jhpiego', 'Monday, 1 July 2019 16:25:44', 'Jhpiego'),
(24, 3, 5, 'O provedor explica ao detalhe as quest&otilde;es que vai fazer para compor um plano de seguran&ccedil;a com utente', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 16:22:28', 'Jhpiego', 'Monday, 1 July 2019 16:25:51', 'Jhpiego'),
(25, 3, 5, 'O provedor faz perguntas directas  e simples sobre viol&ecirc;ncia e documenta.', 'E, D', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 16:22:56', 'Jhpiego', 'Monday, 1 July 2019 16:25:37', 'Jhpiego'),
(26, 3, 6, 'O provedor faz perguntas simples e directas para avaliar sinais de perigo de vida  imediato:\r\n&bull;     A viol&ecirc;ncia tem sido cada vez mais frequente nos &uacute;ltimos 6 meses ?\r\n&bull;     Ele /e  usou ou amea&ccedil;ou uma arma ?\r\n&bull;     Ele/a tentou estrangular ?\r\n&bull;     Acredita que ele/a possa matar &ndash;te ?\r\n&bull;     Alguma vez ele /a bateu durante a gravidez ?\r\n&bull;     Ele /a tem comportamento violento constante ?', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 16:25:02', 'Jhpiego', 'Monday, 1 July 2019 16:33:04', 'Jhpiego'),
(27, 3, 6, 'Se o utente responde SIM a alguma das perguntas  ou se o utente pede abrigo o provedor faz as refer&ecirc;ncias para espa&ccedil;os seguros com apoio de familiares ou recursos comunit&aacute;rios.', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 16:34:38', 'Jhpiego', NULL, NULL),
(28, 3, 6, 'O provedor apoia a fazer o plano de seguran&ccedil;a fazendo as quest&otilde;es descritas abaixo :\r\n\r\n&bull;     Se tiver que sair as pressas de casa para onde iria?\r\n&bull;     Sairia sozinha ou com os seus filhos ? (Se a utente tiver filhos)\r\n&bull;     Que documentos precisaria organizar, dinheiro levaria consigo?\r\n&bull;     Pode guardar pertences essenciais num local seguro caso precise sair de casa ?\r\n&bull;     Onde procuraria ajuda ou dinheiro no caso de emerg&ecirc;ncia ?\r\n&bull;     H&aacute; um  vizinho a quem voc&ecirc; ligaria para chamar a policia se voc&ecirc; estivesse em perigo?', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 16:36:08', 'Jhpiego', NULL, NULL),
(29, 4, 7, 'O provedor obt&eacute;m consetimento escrito ou verbal (assentimento e concord&acirc;ncia da crian&ccedil;a ),   antes de realizar qualquer procedimento e explica os procedimentos ao utente e seus tutores se este for menor', 'E, R', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 16:39:26', 'Jhpiego', NULL, NULL),
(30, 4, 7, 'O provedor obt&eacute;m consentimento para realizar a testagem para HIV de acordo com as normas nacionais', 'E, R', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 16:39:58', 'Jhpiego', NULL, NULL),
(31, 4, 7, 'O provedor segue as normas para obter o consentimento de menores de idade', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 18:20:02', 'Jhpiego', NULL, NULL),
(32, 4, 7, 'O provedor nunca for&ccedil;a o utente a ser examinado a n&atilde;o ser que o exame permita resolver uma situa&ccedil;&atilde;o que perigue a vida do utente', 'E, D, R', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 18:37:01', 'Jhpiego', NULL, NULL),
(33, 4, 7, 'O provedor clarifica que o utente pode recusar  qualquer procedimento.', 'E, D, R', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 18:37:41', 'Jhpiego', NULL, NULL),
(34, 4, 7, 'O provedor respeita a decis&atilde;o do utente de n&atilde;o reportar a policia', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 18:38:11', 'Jhpiego', NULL, NULL),
(35, 4, 7, 'Se o reporte &aacute; policia &aacute; mandat&oacute;rio (e.g.  utente menor ), o provedor reporta o caso e informa aos tutores do utente a import&acirc;ncia de seguir com a refer&ecirc;ncia .', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 18:38:55', 'Jhpiego', NULL, NULL),
(36, 4, 7, 'Os provedores de sa&uacute;de reportam casos de viol&ecirc;ncia contra crian&ccedil;a', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 18:39:29', 'Jhpiego', NULL, NULL),
(37, 4, 8, 'O Provedor avalia e documenta os sinais vitais  da v&iacute;tima', 'E, D, R', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 18:41:02', 'Jhpiego', NULL, NULL),
(38, 4, 8, 'O provedor verifica se o utente est&aacute; estabilizado e verifica os sinais de perigo e corrige-os imediatamente.', 'E, D', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:13:49', 'Jhpiego', NULL, NULL),
(39, 4, 8, 'O provedor faz o tratamento das les&otilde;es genito-anais de acordo com o protocolo.', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:15:07', 'Jhpiego', NULL, NULL),
(40, 4, 8, 'O provedor faz o tratamento das les&otilde;es extragenitas de acordo com o protocolo de avalia&ccedil;&atilde;o de paciente traumatizado colhe as evid&ecirc;ncias medico legais:', 'E, D', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:16:39', 'Jhpiego', NULL, NULL),
(41, 4, 9, 'O provedor demonstra conhecimento,empatia, e habilidades de comunica&ccedil;&atilde;o com os pacientes :\r\nVerifique se o provedor :\r\n&bull;     Realiza escuta activa (escuta sem interromper, n&atilde;o pressiona o paciente a falar)\r\n&bull;     Valida o que o paciente (i.e. da import&acirc;ncia ao o que paciente fala diz )\r\n&bull;     Mostra compaix&atilde;o e preocupa&ccedil;&atilde;o\r\n&bull;     N&atilde;o culpa nem julga o paciente\r\n&bull;     Fala de acordo com o grau de compreens&atilde;o e n&iacute;vel de entendimento do utente\r\n&bull;     Evita usar termos t&eacute;cnicos e usa linguagem simples\r\n&bull;     Usa linguagem verbal e n&atilde;o verbal que o paciente pode entender\r\n&bull;     Encoraja o paciente a fazer perguntas', 'E, D', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:18:26', 'Jhpiego', NULL, NULL),
(42, 4, 10, 'O provedor solicita a presen&ccedil;a de um assistente social  durante  o exame f&iacute;sico ou interac&ccedil;&atilde;o com a pol&iacute;cia  de uma crian&ccedil;a/ adolescente v&iacute;tima de viol&ecirc;ncia', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:19:32', 'Jhpiego', NULL, NULL),
(43, 4, 10, 'O provedor mostra empatia, apoio durante o aconselhamento p&oacute;s trauma e anamnese', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:20:51', 'Jhpiego', NULL, NULL),
(44, 4, 10, 'Se o provedor suspeita de viol&ecirc;ncia dentro de casa, colabora  para apoiar na protec&ccedil;&atilde;o da crian&ccedil;a (abrigo tempor&aacute;rio ou fam&iacute;lia substituta)', 'E, D', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:21:42', 'Jhpiego', NULL, NULL),
(45, 4, 10, 'Em caso de menores, o provedor usa t&eacute;cnicas de comunica&ccedil;&atilde;o apropriadas para crian&ccedil;as .\r\n\r\nPergunta de verifica&ccedil;&atilde;o : Podem nomear uma t&eacute;cnica de comunca&ccedil;&atilde;o apropriada para crian&ccedil;as que usa com os utentes ?\r\n(Marque SIM se o provedor mencionar tr&ecirc;s ou mais exemplos descritos abaixo)\r\n&bull;     Valida a experi&ecirc;ncia da crian&ccedil;a e elogia &ndash;a por rep&oacute;rter  sem culp&aacute;-la\r\n&bull;     D&aacute; possibilidade a crian&ccedil;a de fazer escolhas (Esta t&eacute;cnica ajuda a crian&ccedil;a a recuperar o controlo e sentir-se imponderada.\r\n&bull;     Faz uma pergunta de cada vez.\r\n&bull;     Evita perguntas directas ( Ex.Ao inv&eacute;s de perguntar &ldquo;Ele/a tocou-te nos genitais?&rdquo; pode perguntar  (&ldquo;Onde ele/a te tocou ?)\r\n&bull;     Evita fazer muitas perguntas ou perguntas fechadas isto pode confundir a crian&ccedil;a e fazer com que esta forne&ccedil;a informa&ccedil;&otilde;es erradas ou contradit&oacute;rias (Ex. Ao inv&eacute;s de perguntar &ldquo;Quem fez isso foi uma pessoa foi um estranho, um vizinho, familiar ou colega de escola ?)\r\n&bull;     Evita perguntar a crian&ccedil;a abaixo de 10 anos sobre quando ocorreu o epis&oacute;dio de viol&ecirc;ncia pois estes n&atilde;o t&ecirc;m no&ccedil;&atilde;o do tempo.', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:24:02', 'Jhpiego', NULL, NULL),
(46, 4, 10, 'O provedor permite que a crian&ccedil;a se fa&ccedil;a acompanhar por um tutor ou pelos pais durante o exame f&iacute;sico. (Desde que n&atilde;o sejam perpetradores )', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:24:57', 'Jhpiego', NULL, NULL),
(47, 4, 10, 'O provedor n&atilde;o usa especulo durante o exame genito&ndash;anal a n&atilde;o ser para reparar les&otilde;es no canal vaginal sob anestesia adequada para cada caso', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:25:40', 'Jhpiego', NULL, NULL),
(48, 4, 10, 'A US usa bonecas/os , papel, l&aacute;pis apropriados para facilitar a anamese em crian&ccedil;as', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:26:26', 'Jhpiego', NULL, NULL),
(49, 4, 11, 'O provedor n&atilde;o partilha informa&ccedil;&otilde;es relacionadas com o caso com pessoas que n&atilde;o est&atilde;o envolvidas no tratamento do paciente.', 'E, R', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:28:14', 'Jhpiego', NULL, NULL),
(50, 4, 11, 'O Provedor permite que apenas pessoal autorizado esteja presente na sala de consulta durante o atendimento.', 'E, R', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:29:31', 'Jhpiego', NULL, NULL),
(51, 4, 11, 'O provedor oferece um local adequado com privacidade e tempo para o paciente despir-se e vestir-se para  realizar exame f&iacute;sico.', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:29:48', 'Jhpiego', NULL, NULL),
(52, 4, 11, 'A US mant&eacute;m os registos m&eacute;dicos legais, evid&ecirc;ncias e outros documentos relevantes com identificadores pessoais (Nome , endere&ccedil;o etc.) num cacifo fechado a chave de acordo com recomenda&ccedil;&otilde;es nacionais.', 'E, D, R', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:31:37', 'Jhpiego', NULL, NULL),
(53, 4, 11, 'A US possui as politicas nacionais que orientam o acesso aos registos medico legais e forenses', 'E, D, R', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:32:20', 'Jhpiego', NULL, NULL),
(54, 4, 12, 'O provedor controla a dor durante o exame f&iacute;sico de acordo com o protocolo.', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:33:22', 'Jhpiego', NULL, NULL),
(55, 4, 12, 'Provedor oferece medica&ccedil;&atilde;o para al&iacute;vio da dor quando necess&aacute;rio.', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:33:51', 'Jhpiego', NULL, NULL),
(56, 4, 12, 'O provedor mant&eacute;m o corpo do utente coberto com len&ccedil;&oacute;is ou pijama para evitar exposi&ccedil;&atilde;o desnecess&aacute;ria e revitimiza&ccedil;&atilde;o.', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:34:28', 'Jhpiego', NULL, NULL),
(57, 4, 12, 'A US oferece ao utente a possibilidade de escolher  sexo do provedor que vai realizar o exame f&iacute;sico .', 'E, D, R', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:35:12', 'Jhpiego', NULL, NULL),
(58, 4, 12, 'A US oferece uma refei&ccedil;&atilde;o simples ap&oacute;s exame f&iacute;sico.', 'E, D, R', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:35:44', 'Jhpiego', NULL, NULL),
(59, 4, 16, 'Provedor regista na ficha de primeira inten&ccedil;&atilde;o todos achados do exame f&iacute;sico e tratamentos realizados de forma detalhada e documentada na ficha de notifica&ccedil;&atilde;o ou di&aacute;rio cl&iacute;nico e na ficha  de primeira inten&ccedil;&atilde;o.', 'E, R', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:36:32', 'Jhpiego', NULL, NULL),
(60, 4, 16, 'O provedor usa especulo apenas quando apropriado e s&oacute; quando est&aacute; formado para tal.\r\nPergunta de verifica&ccedil;&atilde;o : Quando usa especulo?\r\n\r\nPro&iacute;be: Em que condi&ccedil;&otilde;es acha que o uso do especulo &eacute; apropriado?\r\n&bull;     Quando suspeita de uma les&atilde;o no canal vaginal com sangramento numa crian&ccedil;a.\r\n&bull;     Quando n&atilde;o tem indica&ccedil;&atilde;o cl&iacute;nica\r\n&bull;     Quando o paciente recusa\r\n&bull;     Quando o provedor n&atilde;o foi formado para usar o especulo\r\n&bull;     Se o paciente tiver mais de 20 semanas de gravidez ou se tiver sangramento', 'E, R', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:38:21', 'Jhpiego', NULL, NULL),
(61, 4, 16, 'Se o paciente tiver sido estrangulado o provedor pede para este retornar a US se sentir subitamente : dificuldade respirat&oacute;ria, altera&ccedil;&atilde;o do timbre da voz, stress respirat&oacute;rio at&eacute; 72 horas depois da viol&ecirc;ncia\r\n\r\n Pro&iacute;be : Se o utente tiver sido estrangulado h&aacute; alguma recomenda&ccedil;&atilde;o que daria a ele ? Porque ?', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:39:19', 'Jhpiego', NULL, NULL),
(62, 4, 16, 'O provedor de sa&uacute;de usa o anosc&oacute;pio para exame anal se a v&iacute;tima tiver sangramento anal abundante, ou refere para unidade sanit&aacute;ria com capacidade cir&uacute;rgica.', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:39:55', 'Jhpiego', NULL, NULL),
(63, 4, 14, 'O provedor oferece medicamentos orais para  contracep&ccedil;&atilde;o de emerg&ecirc;ncia (CE)  dentro de 120 horas ( 5 dias ) a p&oacute;s o contacto sexual.', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:40:46', 'Jhpiego', NULL, NULL),
(64, 4, 14, 'Se CE oral n&atilde;o estiver dispon&iacute;vel ou se houver alguma contra-indica&ccedil;&atilde;o , um provedor treinado pode inserir dispositivo intrauterine (DIU) sempre que o utente optar com contracep&ccedil;&atilde;o de longa dura&ccedil;&atilde;o\r\n\r\nPergunta de Verifica&ccedil;&atilde;o : Se CE por via oral n&atilde;o estiver dispon&iacute;vel, pode inserir um DIU ? \r\n\r\nPro&iacute;be 1: ( Se a resposta do provedor for SIM) Voc&ecirc; foi treinado para inserir DIU ?\r\n\r\nPro&iacute;be 2: (Se a resposta do provedor for SIM) O Voc&ecirc; confirma com a utente primeiro se esta deseja fazer contracep&ccedil;&atilde;o de longa dura&ccedil;&atilde;o antes de inserir o DIU ?', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:41:57', 'Jhpiego', NULL, NULL),
(65, 4, 14, 'Se o utente desejar contracep&ccedil;&atilde;o de longa dura&ccedil;&atilde;o com DIU o provedor treinado insere o DIU  em 120 horas (5 dias ) depois do contacto sexual.', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:42:22', 'Jhpiego', NULL, NULL),
(66, 4, 14, 'Se o utente recusa contracep&ccedil;&atilde;o de emerg&ecirc;ncia (CE), o provedor oferece  informa&ccedil;&atilde;o sobre import&acirc;ncia de contracep&ccedil;&atilde;o e seguimento para realizar teste de gravidez.', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:43:00', 'Jhpiego', NULL, NULL),
(67, 4, 15, 'O provedor oferece aconselhamento e testagem para HIV para v&iacute;timas de viol&ecirc;ncia sexual de acordo com os protocolos nacionais', 'E, R', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:52:15', 'Jhpiego', NULL, NULL),
(68, 4, 15, 'Se o teste do HIV for negativo e n&atilde;o tiverem passado 72H ap&oacute;s a ocorr&ecirc;ncia de viol&ecirc;ncia sexual, o provedor informa ao utente sobre o factores de risco para infec&ccedil;&atilde;o pelo HIV e determina com o utente se este necessita iniciar PPE .\r\nPergunta de verifica&ccedil;&atilde;o :  Se o utente for HIV negativo que informa&ccedil;&otilde;es voc&ecirc;  forneceria ao utente ?\r\n(Se o provedor responder SIM a um ou mais factores de risco discutidos com os utentes)\r\n&bull;     A natureza da viol&ecirc;ncia sexual ( Que orif&iacute;cios foram penetrados, se ouve ou n&atilde;o les&atilde;o anal ou genital etc.)\r\n&bull;     O sero estado do HIV do perpetrador ou se for desconhecido\r\n&bull;     N&uacute;mero de perpetradores\r\n&bull;     Incid&ecirc;ncia de HIV na &aacute;rea geogr&aacute;fica', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:54:26', 'Jhpiego', NULL, NULL),
(69, 4, 15, 'Se o utente for HIV negativo e a viol&ecirc;ncia sexual tiver ocorrido  dentro de 72H o provedor oferece o a dose completa de PPE para 28 dias de acordo com as recomenda&ccedil;&otilde;es nacionais   Ex. o provedor da a dose completa de PPE para o utente n&atilde;o ter que voltar ou interromper PPE)', 'E, R', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:55:21', 'Jhpiego', NULL, NULL),
(70, 4, 15, 'Se o utente &eacute; uma crian&ccedil;a e o teste para HIV for negativo e a ocorr&ecirc;ncia de viol&ecirc;ncia sexual for dentro das 72H o provedor oferece o a dose complete pedi&aacute;trica de acordo com os protocolos nacionais', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:55:50', 'Jhpiego', NULL, NULL),
(71, 4, 15, 'Se PPE for for administrado, o provedor aconselha sobre efeitos colaterais, import&acirc;ncia da ades&atilde;o e de completar o ciclo completo de PPE  para garantir que a PPE seja efectiva na redu&ccedil;&atilde;o do risco de transmiss&atilde;o do HIV', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:56:48', 'Jhpiego', NULL, NULL),
(72, 4, 15, 'A US possui um sistema de seguimento de utentes fazem PPE e documenta se os utentes terminam o regime de PPE', 'E, R', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:57:33', 'Jhpiego', NULL, NULL),
(73, 4, 15, 'Se o utente for HIV positivo, e estiver dispon&iacute;vel para partilhar o sero estado com o parceiro o provedor avaliar a possibilidade de viol&ecirc;ncia por parceiro &iacute;ntimo par evitar viol&ecirc;ncia relacionada &aacute; revela&ccedil;&atilde;o de sero estado\r\nPergunta de Verifica&ccedil;&atilde;o :  Se o utente for HIV positive e que revele ao seu parceiro o que voc&ecirc; diria ou fazer ?', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:58:31', 'Jhpiego', NULL, NULL),
(74, 4, 15, 'Se o utente recusa fazer teste para HIV ou tem o ser estado desconhecido e se a ocorr&ecirc;ncia de viol&ecirc;ncia foi a menos de 72 Horas , o provedor oferece PPE e encoraja o utente a regressar para aconselhamento e testagem para HIV', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 20:59:57', 'Jhpiego', NULL, NULL),
(75, 4, 17, 'O provedor oferece a profilaxia ou tratamento para ITS de acordo com as normas nacionais', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 21:00:41', 'Jhpiego', NULL, NULL),
(76, 4, 17, 'Provedor oferece vacina&ccedil;&atilde;o antitet&acirc;nica de acordo com o protocolo nacional.', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 21:01:20', 'Jhpiego', NULL, NULL),
(77, 4, 17, 'O provedor oferece a  vacina&ccedil;&atilde;o para Hepatite B dentro de 24 horas ap&oacute;s a ocorr&ecirc;ncia de viol&ecirc;ncia sexual de acordo com a elegibilidade do utente de acordo com as recomenda&ccedil;&otilde;es nacionais.\r\n\r\n(ISe a vacina&ccedil;&atilde;o para hepatite B n&atilde;o est&aacute; dispon&iacute;vel escreva  &ldquo;N/A&rdquo; nos coment&aacute;rios e n&atilde;o conte o padr&atilde;o).', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 21:03:42', 'Jhpiego', NULL, NULL),
(78, 4, 18, 'O provedor oferece aconselhamento p&oacute;s trauma : escuta activamente, &eacute; emp&aacute;tico , parafraseia, e identifica necessidades de apoio social', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 21:04:30', 'Jhpiego', NULL, NULL),
(79, 4, 18, 'Provedores t&ecirc;m conhecimento sobre servi&ccedil;os de sa&uacute;de mental a serem oferecidos de acordo com  as recomenda&ccedil;&otilde;es nacionais or OMS.', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 21:05:03', 'Jhpiego', NULL, NULL),
(80, 4, 18, 'Provedor oferece referencias para seguimento psicol&oacute;gico de longo termo OU  atrav&eacute;s dos grupos de apoio.', 'E, R', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 21:05:37', 'Jhpiego', NULL, NULL),
(81, 5, 16, 'O provedor realiza avalia&ccedil;&atilde;o medico legal e as seguintes condi&ccedil;&otilde;es est&atilde;o criadas :\r\n(op&ccedil;&otilde;es)\r\nSe algum destes requisitos n&atilde;o tiver sido observado, a aten&ccedil;&atilde;o medico legal &eacute; considerada inadequada  e os provedores n&atilde;o devem realizar exames m&eacute;dico legal.', 'E, R', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 21:08:06', 'Jhpiego', NULL, NULL),
(82, 5, 16, 'O provedor que foi treinado para realizar a avalia&ccedil;&atilde;o medico legal colhe a hist&oacute;ria de do paciente ou tutor acordo com as recomenda&ccedil;&otilde;es nacionais', 'E, R', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 21:08:47', 'Jhpiego', NULL, NULL),
(83, 5, 16, 'O provedor treinado colhe as evid&ecirc;ncias forenses e documenta de forma apropriada as les&otilde;es dentro de 5 dias depois da ocorr&ecirc;ncia de viol&ecirc;ncia sexual ou a qualquer forma de viol&ecirc;ncia  baseado na hist&oacute;ria fornecida pelo o utente que inclue :\r\n&bull;     Zaragatoa vaginal, perianal, anal ou oral (de acordo com a hist&oacute;ria).\r\n&bull;     Colher a zaragatoa de controlo para poder comparar com a zaragatoa com evid&ecirc;ncia (Se assim for indicado)\r\n&bull;     Colher amostras do leito ungueal (Se estiver indicado)\r\n&bull;     Testar a roupa interior para presen&ccedil;a de s&eacute;men ou fluidos org&acirc;nicos, pele, cabelo ou objectos como zippers entre outros \r\n&bull;     Recolher pelos p&uacute;bicos que estejam na roupa da v&iacute;tima\r\n&bull;     Avaliar a presen&ccedil;a de vest&iacute;gios do local de facto na roupa ou na pele da v&iacute;tima (Relva, areia etc.)\r\n&bull;     Colher zaragatoas h&uacute;midas no corpo da v&iacute;tima (e.g., onde o perpetrador possa ter mordido, beijado ou ejaculado de acordo com hist&oacute;ria)\r\n&bull;     Colher evid&ecirc;ncia usando fonte de luz alternativa que reconhece vest&iacute;gios de l&iacute;quidos e tecidos humanos (S&eacute;men, urina e saliva )\r\n&bull;     Realizar foto de documenta&ccedil;&atilde;o forense de les&otilde;es', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 21:11:17', 'Jhpiego', 'Wednesday, 3 July 2019 15:17:39', 'Jhpiego'),
(84, 5, 19, 'O provedor est&aacute; consciente sobre a import&acirc;ncia das evid&ecirc;ncias forenses para julgamento dos casos.', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 21:12:12', 'Jhpiego', NULL, NULL),
(85, 5, 19, 'Os provedores usam um protocolo estandardizado  para colher , selar e armazenar evid&ecirc;ncias forenses', 'E, R', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 21:13:11', 'Jhpiego', NULL, NULL),
(86, 5, 19, 'Os provedores est&atilde;o alerta a sinais mais frequentes de lacera&ccedil;&otilde;es, eritemas que indicam viol&ecirc;ncia .', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 21:13:47', 'Jhpiego', NULL, NULL),
(87, 5, 19, 'Provedor faz quest&otilde;es para clarificar e entender as les&otilde;es observadas que n&atilde;o condizem com a hist&oacute;ria cl&iacute;nica.', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 21:14:23', 'Jhpiego', NULL, NULL),
(88, 5, 19, 'O provedor usa equipamento de protec&ccedil;&atilde;o individual (barrete, mascara cir&uacute;rgica, luvas, avental, sapatos fechados ) quando realiza o exame medico legal .', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 21:15:00', 'Jhpiego', NULL, NULL),
(89, 5, 19, 'O provedor colhe evid&ecirc;ncias forenses para viol&ecirc;ncia sexual dentro de 5 dias.', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 21:43:12', 'Jhpiego', NULL, NULL),
(90, 5, 19, 'O provedor realiza a colecta de amostras forenses primeiro e testa-as logo de seguida.', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 21:44:30', 'Jhpiego', NULL, NULL),
(91, 5, 19, 'O provedor mant&eacute;m a cadeia de cust&oacute;dia  para seguran&ccedil;a, colecta, armazenamento e transporte de evid&ecirc;ncias e foto documenta&ccedil;&atilde;o.', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 21:48:11', 'Jhpiego', NULL, NULL),
(92, 5, 19, 'A Unidade Sanit&aacute;ria tem sistema para minimizar o n&uacute;mero de pessoas que maneja a cadeia de cust&oacute;dia.', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 21:49:46', 'Jhpiego', NULL, NULL),
(93, 5, 19, 'A US tem Sistema de apoio para o provedor testemunhar em tribunal caso seja solicitado', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 21:50:18', 'Jhpiego', NULL, NULL),
(94, 5, 19, 'Se o utente da o consentimento, o provedor fornece foto documenta&ccedil;&atilde;o das les&otilde;es para que seja usadas como prova\r\n\r\n( O uso de telefones celulares pessoais n&atilde;o &eacute; recomendado por quest&otilde;es de seguran&ccedil;a e privacidade)', 'E', NULL, 1, 'Activo', 0, 'Monday, 1 July 2019 21:50:43', 'Jhpiego', NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `sa_district`
--

CREATE TABLE `sa_district` (
  `id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `province_id` int(11) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  `DateCreate` varchar(45) DEFAULT NULL,
  `DateCreateUser` varchar(45) DEFAULT NULL,
  `LastUpDate` varchar(45) DEFAULT NULL,
  `LastUpDateUser` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `sa_district`
--

INSERT INTO `sa_district` (`id`, `name`, `province_id`, `status`, `deleted`, `DateCreate`, `DateCreateUser`, `LastUpDate`, `LastUpDateUser`) VALUES
(1, 'Quelimane', 1, 'Activo', 0, '2019-06-19 02:21:17', 'Jhpiego', 'Tuesday, 9 July 2019 11:35:58', 'Jhpiego'),
(2, 'Nicoadala', 1, 'Activo', 0, '2019-06-19 02:21:17', 'Jhpiego', 'Tuesday, 9 July 2019 11:34:17', 'Jhpiego'),
(3, 'Boane', 2, 'Activo', 0, '2019-06-19 02:21:17', 'Jhpiego', 'Tuesday, 9 July 2019 11:36:57', 'Jhpiego'),
(4, 'Beira', 8, 'Activo', 0, '2019-06-19 02:21:17', 'Jhpiego', 'Tuesday, 9 July 2019 11:37:17', 'Jhpiego'),
(5, 'N&atilde;o listado', 19, 'Activo', 0, '2019-06-19 14:58:17', 'Jhpiego', 'Tuesday, 9 July 2019 11:59:35', 'Jhpiego'),
(6, 'Paran&aacute;', 19, 'Activo', 0, '2019-06-19 14:58:17', 'Jhpiego', 'Tuesday, 9 July 2019 11:59:58', 'Jhpiego'),
(7, 'Xai-Xai', 5, 'Activo', 0, '2019-06-21 14:58:10', 'Jhpiego', 'Tuesday, 9 July 2019 12:00:29', 'Jhpiego'),
(8, 'Morrumbala', 1, 'Activo', 0, '2019-06-21 14:59:02', 'Jhpiego', 'Tuesday, 9 July 2019 12:00:37', 'Jhpiego'),
(9, 'Gil&eacute;', 1, 'Activo', 0, '2019-06-21 15:29:19', 'Jhpiego', 'Tuesday, 9 July 2019 12:00:47', 'Jhpiego'),
(10, 'Pemba', 4, 'Activo', 0, NULL, 'Jhpiego', 'Tuesday, 9 July 2019 12:01:10', 'Jhpiego'),
(11, 'Nacala', 3, 'Activo', 0, 'Monday, 24 June 2019 01:08:50', 'Jhpiego', 'Tuesday, 9 July 2019 12:01:21', 'Jhpiego');

-- --------------------------------------------------------

--
-- Estrutura da tabela `sa_employment`
--

CREATE TABLE `sa_employment` (
  `id` int(11) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `DateCreated` varchar(45) DEFAULT NULL,
  `DateCreateUser` varchar(150) DEFAULT NULL,
  `LastUpDate` varchar(45) DEFAULT NULL,
  `LastUpDateUser` varchar(150) DEFAULT NULL,
  `deleted` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `sa_employment`
--

INSERT INTO `sa_employment` (`id`, `name`, `status`, `DateCreated`, `DateCreateUser`, `LastUpDate`, `LastUpDateUser`, `deleted`) VALUES
(1, 'M&eacute;dico Chefe Distrital', 'Activo', NULL, 'Jhpiego', 'Wednesday, 10 July 2019 13:49:59', 'Jhpiego', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `sa_evaluation`
--

CREATE TABLE `sa_evaluation` (
  `id` int(11) NOT NULL,
  `comment` varchar(150) DEFAULT NULL,
  `status_yes` varchar(3) DEFAULT NULL,
  `criterion_evaluation_id` int(11) DEFAULT NULL,
  `employment_id` int(11) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  `DateCreate` varchar(45) DEFAULT NULL,
  `DateCreateUser` varchar(45) DEFAULT NULL,
  `LastUpDate` varchar(45) DEFAULT NULL,
  `LastUpDateUser` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `sa_evaluation`
--

INSERT INTO `sa_evaluation` (`id`, `comment`, `status_yes`, `criterion_evaluation_id`, `employment_id`, `status`, `deleted`, `DateCreate`, `DateCreateUser`, `LastUpDate`, `LastUpDateUser`) VALUES
(1, '', NULL, 94, NULL, NULL, 0, 'Tuesday, 2 July 2019 13:01:26', 'Jhpiego', NULL, NULL),
(2, NULL, NULL, 94, NULL, NULL, 0, 'Tuesday, 2 July 2019 20:24:47', 'Jhpiego', NULL, NULL),
(3, '', NULL, 93, NULL, NULL, 0, 'Wednesday, 3 July 2019 17:45:39', 'Jhpiego', NULL, NULL),
(4, '', NULL, 93, NULL, NULL, 0, 'Monday, 8 July 2019 15:50:19', 'Jhpiego', NULL, NULL),
(5, '', NULL, 93, NULL, NULL, 0, 'Monday, 8 July 2019 15:52:21', 'Jhpiego', NULL, NULL),
(6, '', NULL, 93, NULL, NULL, 0, 'Monday, 8 July 2019 15:57:29', 'Jhpiego', NULL, NULL),
(7, '', NULL, 93, NULL, NULL, 0, 'Monday, 8 July 2019 17:07:11', 'Jhpiego', NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `sa_evaluation_type`
--

CREATE TABLE `sa_evaluation_type` (
  `id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `sanitary_unit_id` int(11) DEFAULT NULL,
  `district_id` int(11) DEFAULT NULL,
  `date` varchar(45) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `team_medition` varchar(200) DEFAULT NULL,
  `employment_id` int(11) DEFAULT NULL,
  `period` int(11) DEFAULT NULL,
  `status` varchar(10) DEFAULT 'Activo',
  `deleted` tinyint(4) DEFAULT NULL,
  `DateCreate` varchar(45) DEFAULT NULL,
  `DateCreateUser` varchar(45) DEFAULT NULL,
  `LastUpDate` varchar(45) DEFAULT NULL,
  `LastUpDateUser` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `sa_evaluation_type`
--

INSERT INTO `sa_evaluation_type` (`id`, `name`, `sanitary_unit_id`, `district_id`, `date`, `user_id`, `team_medition`, `employment_id`, `period`, `status`, `deleted`, `DateCreate`, `DateCreateUser`, `LastUpDate`, `LastUpDateUser`) VALUES
(1, 'Interna', 1, 2, '07/09/2019', 5, 'Equipe 1', NULL, NULL, 'Activo', 0, 'Saturday, 29 June 2019 10:41:18', 'Jhpiego', 'Monday, 8 July 2019 11:38:39', 'Jhpiego'),
(5, 'Interna', 1, 2, '07/09/2019', 5, 'Equipe 2', NULL, NULL, 'Activo', 0, 'Tuesday, 9 July 2019 16:40:37', 'Jhpiego', NULL, NULL),
(6, 'Interna', 1, 2, '07/08/2019', 5, 'Equipe 3, Equipe 4', NULL, NULL, NULL, 0, 'Tuesday, 9 July 2019 16:44:05', 'Jhpiego', NULL, NULL),
(7, 'Interna', 1, 2, '07/08/2019', 5, 'Equipe 3, Equipe 4', NULL, NULL, NULL, 0, 'Tuesday, 9 July 2019 16:45:18', 'Jhpiego', NULL, NULL),
(8, 'Externa', 1, 11, '07/09/2019', 5, 'Equipe 3, Equipe 4', NULL, NULL, NULL, 0, 'Tuesday, 9 July 2019 17:03:07', 'Jhpiego', NULL, NULL),
(9, 'Interna', 1, 2, '07/10/2019', 5, 'Equipe 2', 1, NULL, NULL, 0, 'Wednesday, 10 July 2019 15:18:57', 'Jhpiego', NULL, NULL),
(10, 'Interna', 1, 2, '07/10/2019', 5, 'Equipe 3, Equipe 4', 1, NULL, NULL, 0, 'Wednesday, 10 July 2019 15:25:36', 'Jhpiego', NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `sa_instance`
--

CREATE TABLE `sa_instance` (
  `id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  `DateCreate` varchar(45) DEFAULT NULL,
  `DateCreateUser` varchar(45) DEFAULT NULL,
  `LastUpDate` varchar(45) DEFAULT NULL,
  `LastUpDateUser` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `sa_instance`
--

INSERT INTO `sa_instance` (`id`, `name`, `status`, `deleted`, `DateCreate`, `DateCreateUser`, `LastUpDate`, `LastUpDateUser`) VALUES
(1, 'Unidade Sanit&aacute;ria', 'Activo', 0, NULL, NULL, 'Wednesday, 10 July 2019 20:07:27', 'Jhpiego'),
(2, 'Policia', 'Activo', 0, 'Wednesday, 10 July 2019 20:05:41', 'Jhpiego', NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `sa_intervention`
--

CREATE TABLE `sa_intervention` (
  `id` int(11) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `cause_id` int(11) DEFAULT NULL,
  `order_intervention` text,
  `status` varchar(10) DEFAULT NULL,
  `DateCreated` varchar(45) DEFAULT NULL,
  `DateCreateUser` varchar(150) DEFAULT NULL,
  `LastUpDate` varchar(45) DEFAULT NULL,
  `LastUpDateUser` varchar(150) DEFAULT NULL,
  `deleted` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `sa_intervention`
--

INSERT INTO `sa_intervention` (`id`, `name`, `cause_id`, `order_intervention`, `status`, `DateCreated`, `DateCreateUser`, `LastUpDate`, `LastUpDateUser`, `deleted`) VALUES
(1, 'Teste 1.1', 2, '1.1', 'Activo', NULL, 'Jhpiego', 'Wednesday, 10 July 2019 19:53:25', 'Jhpiego', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `sa_means_verification`
--

CREATE TABLE `sa_means_verification` (
  `id` int(11) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  `DateCreate` varchar(45) DEFAULT NULL,
  `DateCreateUser` varchar(45) DEFAULT NULL,
  `LastUpDate` varchar(45) DEFAULT NULL,
  `LastUpDateUser` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `sa_means_verification`
--

INSERT INTO `sa_means_verification` (`id`, `name`, `status`, `deleted`, `DateCreate`, `DateCreateUser`, `LastUpDate`, `LastUpDateUser`) VALUES
(1, 'Entrevista', 'Activo', 0, 'Saturday, 29 June 2019 14:12:44', 'Jhpiego', 'Saturday, 29 June 2019 17:41:14', 'Jhpiego'),
(2, 'D', 'Activo', 0, 'Saturday, 29 June 2019 14:12:57', 'Jhpiego', 'Saturday, 29 June 2019 14:16:56', 'Jhpiego'),
(3, 'R', 'Activo', 0, 'Saturday, 29 June 2019 14:17:05', 'Jhpiego', NULL, NULL),
(4, 'O', 'Activo', 0, 'Saturday, 29 June 2019 17:41:38', 'Jhpiego', NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `sa_province`
--

CREATE TABLE `sa_province` (
  `id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  `DateCreate` varchar(45) DEFAULT NULL,
  `DateCreateUser` varchar(45) DEFAULT NULL,
  `LastUpDate` varchar(45) DEFAULT NULL,
  `LastUpDateUser` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `sa_province`
--

INSERT INTO `sa_province` (`id`, `name`, `country_id`, `status`, `deleted`, `DateCreate`, `DateCreateUser`, `LastUpDate`, `LastUpDateUser`) VALUES
(1, 'Zamb&eacute;zia', 1, 'Activo', 0, 'Saturday, 22 June 2019 15:21:07', 'Jhpiego', 'Saturday, 29 June 2019 13:41:39', 'Jhpiego'),
(2, 'Maputo', 1, 'Activo', 0, 'Friday, 28 June 2019 08:07:07', 'Jhpiego', NULL, NULL),
(3, 'Nampula', 1, 'Activo', 0, '2019-06-19 14:46:34', 'Jhpiego', 'Saturday, 29 June 2019 14:05:44', 'Jhpiego'),
(4, 'Cabo Delgado', 1, 'Activo', 0, '2019-06-19 14:55:43', 'Jhpiego', 'Tuesday, 9 July 2019 11:39:13', 'Jhpiego'),
(5, 'Gaza', 1, 'Activo', 0, '2019-06-19 14:55:43', 'Jhpiego', 'Tuesday, 9 July 2019 11:39:19', 'Jhpiego'),
(6, 'Inhambane', 1, 'Activo', 0, '2019-06-19 14:55:43', 'Jhpiego', 'Tuesday, 9 July 2019 11:39:26', 'Jhpiego'),
(7, 'Tete', NULL, NULL, 1, '2019-06-19 14:55:43', 'Jhpiego', '2019-06-22 13:14:52', NULL),
(8, 'Sofala', 1, 'Activo', 0, '2019-06-19 14:55:43', 'Jhpiego', 'Tuesday, 9 July 2019 11:39:31', 'Jhpiego'),
(9, 'Niassa', 1, 'Activo', 0, '2019-06-19 14:55:43', 'Jhpiego', 'Tuesday, 9 July 2019 11:39:39', 'Jhpiego'),
(10, 'Rio de Janeiro', 1, 'Activo', 0, '2019-06-19 14:55:43', 'Jhpiego', 'Tuesday, 9 July 2019 11:39:45', 'Jhpiego'),
(11, 'Lisboa', 8, 'Activo', 0, '2019-06-19 14:55:43', 'Jhpiego', 'Tuesday, 9 July 2019 11:40:05', 'Jhpiego'),
(12, 'Campina Grande', 2, 'Activo', 0, '2019-06-19 14:55:43', 'Jhpiego', 'Tuesday, 9 July 2019 11:52:12', 'Jhpiego'),
(13, 'Nova York', 3, 'Activo', 0, '2019-06-22 13:22:28', 'Jhpiego', 'Tuesday, 9 July 2019 11:52:28', 'Jhpiego'),
(14, 'Chicago', 15, 'Activo', 0, '2019-06-22 13:22:34', 'Jhpiego', 'Tuesday, 9 July 2019 11:57:20', 'Jhpiego'),
(15, 'Teste', NULL, NULL, 1, '2019-06-22 13:10:54', 'Jhpiego', '2019-06-22 13:14:52', 'Jhpiego'),
(16, 'Teste 2', NULL, NULL, 1, NULL, 'Jhpiego', 'Saturday, 22 June 2019 16:23:18', 'Jhpiego'),
(17, 'teste 3', NULL, NULL, 1, 'Saturday, 22 June 2019 15:21:07', 'Jhpiego', 'Saturday, 22 June 2019 15:21:17', 'Jhpiego'),
(18, 'Teste 4', NULL, NULL, 1, 'Saturday, 22 June 2019 16:32:24', 'Jhpiego', NULL, NULL),
(19, 'N&atilde;o Listado', 14, 'Activo', 0, 'Tuesday, 9 July 2019 11:59:20', 'Jhpiego', NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `sa_quarter`
--

CREATE TABLE `sa_quarter` (
  `id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `administrative_rate_id` int(11) DEFAULT NULL,
  `district_id` int(11) DEFAULT NULL,
  `province_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  `DateCreate` varchar(45) DEFAULT NULL,
  `DateCreateUser` varchar(45) DEFAULT NULL,
  `LastUpDate` varchar(45) DEFAULT NULL,
  `LastUpDateUser` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `sa_quarter`
--

INSERT INTO `sa_quarter` (`id`, `name`, `administrative_rate_id`, `district_id`, `province_id`, `country_id`, `status`, `deleted`, `DateCreate`, `DateCreateUser`, `LastUpDate`, `LastUpDateUser`) VALUES
(1, 'Floresta', NULL, 1, 1, 1, 'Activo', 0, 'Thursday, 4 July 2019 19:04:23', 'Jhpiego', 'Friday, 5 July 2019 00:27:58', 'Jhpiego'),
(2, 'N&atilde;o Listado', NULL, 5, 19, 18, 'Activo', 0, 'Saturday, 6 July 2019 02:50:14', 'Jhpiego', NULL, NULL),
(3, 'Santagua', NULL, 1, 1, 1, 'Activo', 0, 'Saturday, 6 July 2019 02:51:00', 'Jhpiego', NULL, NULL),
(4, 'Bairro Novo Quelimane', NULL, 1, 1, 1, 'Activo', 0, 'Saturday, 6 July 2019 02:51:33', 'Jhpiego', NULL, NULL),
(5, 'Sinacura', NULL, 1, 1, 1, 'Activo', 0, 'Saturday, 6 July 2019 02:51:55', 'Jhpiego', NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `sa_sanitary_unit`
--

CREATE TABLE `sa_sanitary_unit` (
  `id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `province_id` int(11) DEFAULT NULL,
  `district_id` int(11) DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  `DateCreate` varchar(45) DEFAULT NULL,
  `DateCreateUser` varchar(45) DEFAULT NULL,
  `LastUpDate` varchar(45) DEFAULT NULL,
  `LastUpDateUser` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `sa_sanitary_unit`
--

INSERT INTO `sa_sanitary_unit` (`id`, `name`, `status`, `country_id`, `province_id`, `district_id`, `deleted`, `DateCreate`, `DateCreateUser`, `LastUpDate`, `LastUpDateUser`) VALUES
(1, 'Centro de Sa&uacute;de de Nicoadala', 'Activo', 1, 1, 2, 0, 'Saturday, 29 June 2019 14:18:21', 'Jhpiego', NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `sa_service`
--

CREATE TABLE `sa_service` (
  `id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  `DateCreate` varchar(45) DEFAULT NULL,
  `DateCreateUser` varchar(45) DEFAULT NULL,
  `LastUpDate` varchar(45) DEFAULT NULL,
  `LastUpDateUser` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_email` varchar(200) NOT NULL,
  `user_password` varchar(200) NOT NULL,
  `user_name` varchar(200) NOT NULL,
  `fname` varchar(200) DEFAULT NULL,
  `lname` varchar(200) DEFAULT NULL,
  `user_type` enum('master','user') NOT NULL,
  `user_status` enum('Active','Inactive') NOT NULL,
  `employment_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `province_id` int(11) DEFAULT NULL,
  `district_id` int(11) DEFAULT NULL,
  `sanitary_unit_id` int(11) NOT NULL,
  `bairro_id` int(11) NOT NULL,
  `instance_id` int(11) NOT NULL,
  `status` varchar(10) DEFAULT NULL,
  `DateCreate` varchar(45) DEFAULT NULL,
  `LastUpDate` varchar(45) DEFAULT NULL,
  `DateCreateUser` varchar(45) DEFAULT NULL,
  `LastUpDateUser` varchar(45) DEFAULT NULL,
  `deleted` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `user_email`, `user_password`, `user_name`, `fname`, `lname`, `user_type`, `user_status`, `employment_id`, `category_id`, `country_id`, `province_id`, `district_id`, `sanitary_unit_id`, `bairro_id`, `instance_id`, `status`, `DateCreate`, `LastUpDate`, `DateCreateUser`, `LastUpDateUser`, `deleted`) VALUES
(5, 'antychrisfel@gmail.com', '$2y$10$v9LtHIqJRg77F3138Z9w4OGp9SkZZOlViiWA7a/LyHf3es295CDLy', 'Jhpiego', 'Jhpiego', 'António', 'master', 'Active', 1, 1, 1, 1, 2, 1, 1, 0, 'Activo', NULL, NULL, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `user_sessions`
--

CREATE TABLE `user_sessions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `session` varchar(255) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `deleted` tinyint(4) DEFAULT NULL,
  `DateCreate` varchar(45) DEFAULT NULL,
  `DateCreateUser` varchar(45) DEFAULT NULL,
  `LastUpDate` varchar(45) DEFAULT NULL,
  `LastUpDateUser` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deleted` (`deleted`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `migration` (`migration`);

--
-- Indexes for table `sa_administrative_post`
--
ALTER TABLE `sa_administrative_post`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `district_id` (`district_id`),
  ADD KEY `province_id` (`province_id`),
  ADD KEY `country_id` (`country_id`);

--
-- Indexes for table `sa_area`
--
ALTER TABLE `sa_area`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deleted` (`deleted`);

--
-- Indexes for table `sa_area_padrao`
--
ALTER TABLE `sa_area_padrao`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `area_id` (`area_id`);

--
-- Indexes for table `sa_bairro`
--
ALTER TABLE `sa_bairro`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `province_id` (`province_id`),
  ADD KEY `district_id` (`district_id`);

--
-- Indexes for table `sa_category`
--
ALTER TABLE `sa_category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deleted` (`deleted`);

--
-- Indexes for table `sa_cause`
--
ALTER TABLE `sa_cause`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sa_cause_type`
--
ALTER TABLE `sa_cause_type`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cause_id` (`cause_id`);

--
-- Indexes for table `sa_criterion_evaluation`
--
ALTER TABLE `sa_criterion_evaluation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `area_id` (`area_id`),
  ADD KEY `area_padrao_id` (`area_padrao_id`);

--
-- Indexes for table `sa_district`
--
ALTER TABLE `sa_district`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `id_province` (`province_id`);

--
-- Indexes for table `sa_employment`
--
ALTER TABLE `sa_employment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sa_evaluation`
--
ALTER TABLE `sa_evaluation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `criterion_evaluation_id` (`criterion_evaluation_id`);

--
-- Indexes for table `sa_evaluation_type`
--
ALTER TABLE `sa_evaluation_type`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `district_id` (`district_id`),
  ADD KEY `sanitary_unit_id` (`sanitary_unit_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `sa_instance`
--
ALTER TABLE `sa_instance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deleted` (`deleted`);

--
-- Indexes for table `sa_intervention`
--
ALTER TABLE `sa_intervention`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cause_id` (`cause_id`);

--
-- Indexes for table `sa_means_verification`
--
ALTER TABLE `sa_means_verification`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deleted` (`deleted`);

--
-- Indexes for table `sa_province`
--
ALTER TABLE `sa_province`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `country_id` (`country_id`);

--
-- Indexes for table `sa_quarter`
--
ALTER TABLE `sa_quarter`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `administrative_rate_id` (`administrative_rate_id`),
  ADD KEY `district_id` (`district_id`),
  ADD KEY `province_id` (`province_id`),
  ADD KEY `country_id` (`country_id`);

--
-- Indexes for table `sa_sanitary_unit`
--
ALTER TABLE `sa_sanitary_unit`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deleted` (`deleted`),
  ADD KEY `province_id` (`province_id`),
  ADD KEY `district_id` (`district_id`);

--
-- Indexes for table `sa_service`
--
ALTER TABLE `sa_service`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deleted` (`deleted`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `country_id` (`country_id`),
  ADD KEY `district_id` (`district_id`),
  ADD KEY `province_id` (`province_id`),
  ADD KEY `employment_id` (`employment_id`);

--
-- Indexes for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `session` (`session`),
  ADD KEY `deleted` (`deleted`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `country`
--
ALTER TABLE `country`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `sa_administrative_post`
--
ALTER TABLE `sa_administrative_post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sa_area`
--
ALTER TABLE `sa_area`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `sa_area_padrao`
--
ALTER TABLE `sa_area_padrao`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `sa_bairro`
--
ALTER TABLE `sa_bairro`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sa_category`
--
ALTER TABLE `sa_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sa_cause`
--
ALTER TABLE `sa_cause`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sa_cause_type`
--
ALTER TABLE `sa_cause_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sa_criterion_evaluation`
--
ALTER TABLE `sa_criterion_evaluation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT for table `sa_district`
--
ALTER TABLE `sa_district`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `sa_employment`
--
ALTER TABLE `sa_employment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sa_evaluation`
--
ALTER TABLE `sa_evaluation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `sa_evaluation_type`
--
ALTER TABLE `sa_evaluation_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `sa_instance`
--
ALTER TABLE `sa_instance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sa_intervention`
--
ALTER TABLE `sa_intervention`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sa_means_verification`
--
ALTER TABLE `sa_means_verification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sa_province`
--
ALTER TABLE `sa_province`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `sa_quarter`
--
ALTER TABLE `sa_quarter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sa_sanitary_unit`
--
ALTER TABLE `sa_sanitary_unit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sa_service`
--
ALTER TABLE `sa_service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_sessions`
--
ALTER TABLE `user_sessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `sa_administrative_post`
--
ALTER TABLE `sa_administrative_post`
  ADD CONSTRAINT `sa_administrative_post_ibfk_1` FOREIGN KEY (`district_id`) REFERENCES `sa_district` (`id`),
  ADD CONSTRAINT `sa_administrative_post_ibfk_2` FOREIGN KEY (`province_id`) REFERENCES `sa_province` (`id`),
  ADD CONSTRAINT `sa_administrative_post_ibfk_3` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`);

--
-- Limitadores para a tabela `sa_area_padrao`
--
ALTER TABLE `sa_area_padrao`
  ADD CONSTRAINT `sa_area_padrao_ibfk_1` FOREIGN KEY (`area_id`) REFERENCES `sa_area` (`id`);

--
-- Limitadores para a tabela `sa_bairro`
--
ALTER TABLE `sa_bairro`
  ADD CONSTRAINT `sa_bairro_ibfk_1` FOREIGN KEY (`province_id`) REFERENCES `sa_province` (`id`),
  ADD CONSTRAINT `sa_bairro_ibfk_2` FOREIGN KEY (`district_id`) REFERENCES `sa_district` (`id`),
  ADD CONSTRAINT `sa_bairro_ibfk_3` FOREIGN KEY (`district_id`) REFERENCES `country` (`id`);

--
-- Limitadores para a tabela `sa_cause_type`
--
ALTER TABLE `sa_cause_type`
  ADD CONSTRAINT `sa_cause_type_ibfk_1` FOREIGN KEY (`cause_id`) REFERENCES `sa_cause` (`id`);

--
-- Limitadores para a tabela `sa_criterion_evaluation`
--
ALTER TABLE `sa_criterion_evaluation`
  ADD CONSTRAINT `sa_criterion_evaluation_ibfk_1` FOREIGN KEY (`area_id`) REFERENCES `sa_area` (`id`),
  ADD CONSTRAINT `sa_criterion_evaluation_ibfk_2` FOREIGN KEY (`area_padrao_id`) REFERENCES `sa_area_padrao` (`id`);

--
-- Limitadores para a tabela `sa_district`
--
ALTER TABLE `sa_district`
  ADD CONSTRAINT `sa_district_ibfk_1` FOREIGN KEY (`province_id`) REFERENCES `sa_province` (`id`);

--
-- Limitadores para a tabela `sa_evaluation`
--
ALTER TABLE `sa_evaluation`
  ADD CONSTRAINT `sa_evaluation_ibfk_1` FOREIGN KEY (`criterion_evaluation_id`) REFERENCES `sa_criterion_evaluation` (`id`);

--
-- Limitadores para a tabela `sa_evaluation_type`
--
ALTER TABLE `sa_evaluation_type`
  ADD CONSTRAINT `sa_evaluation_type_ibfk_1` FOREIGN KEY (`district_id`) REFERENCES `sa_district` (`id`),
  ADD CONSTRAINT `sa_evaluation_type_ibfk_2` FOREIGN KEY (`sanitary_unit_id`) REFERENCES `sa_sanitary_unit` (`id`),
  ADD CONSTRAINT `sa_evaluation_type_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Limitadores para a tabela `sa_province`
--
ALTER TABLE `sa_province`
  ADD CONSTRAINT `sa_province_ibfk_1` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`),
  ADD CONSTRAINT `sa_province_ibfk_2` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`);

--
-- Limitadores para a tabela `sa_sanitary_unit`
--
ALTER TABLE `sa_sanitary_unit`
  ADD CONSTRAINT `sa_sanitary_unit_ibfk_1` FOREIGN KEY (`province_id`) REFERENCES `sa_province` (`id`),
  ADD CONSTRAINT `sa_sanitary_unit_ibfk_2` FOREIGN KEY (`district_id`) REFERENCES `sa_district` (`id`),
  ADD CONSTRAINT `sa_sanitary_unit_ibfk_3` FOREIGN KEY (`district_id`) REFERENCES `country` (`id`);

--
-- Limitadores para a tabela `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`),
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`district_id`) REFERENCES `sa_district` (`id`),
  ADD CONSTRAINT `users_ibfk_3` FOREIGN KEY (`province_id`) REFERENCES `sa_province` (`id`),
  ADD CONSTRAINT `users_ibfk_4` FOREIGN KEY (`employment_id`) REFERENCES `sa_employment` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
