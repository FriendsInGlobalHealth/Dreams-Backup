<?php
  namespace Migrations;
  use Core\Migration;

  class Migration1561803801 extends Migration {
    public function up() {
      $table = "sa_sanitary_unit";
      $this->createTable($table);
      $this->addColumn($table, 'name','varchar',['size'=>150]);
      $this->addColumn($table, 'status','varchar',['size'=>10]);
      $this->addColumn($table, 'country_id','int');
      $this->addColumn($table, 'province_id','int');
      $this->addColumn($table, 'district_id','int');
      $this->addSoftDelete($table);
      $this->addTimeStamps($table);

      $this->addForeignKey($table, 'province_id', 'sa_province', 'id');
      $this->addForeignKey($table, 'district_id', 'sa_district', 'id');
      $this->addForeignKey($table, 'district_id', 'country', 'id');
    }
  }
  