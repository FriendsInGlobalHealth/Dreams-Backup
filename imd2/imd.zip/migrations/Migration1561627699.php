<?php
  namespace Migrations;
  use Core\Migration;

  class Migration1561627699 extends Migration {
    public function up() {
      $table = "sa_district";
      $this->createTable($table);
      $this->addColumn($table, 'name','varchar',['size'=>150]);
      $this->addColumn($table, 'id_province','int');
      $this->addColumn($table, 'status','varchar',['size'=>10]);
      $this->addSoftDelete($table);
      $this->addTimeStamps($table);

      $this->addForeignKey($table, 'id_province', 'sa_province', 'id');
    }
  }
  