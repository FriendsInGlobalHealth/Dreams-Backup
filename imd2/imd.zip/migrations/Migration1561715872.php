<?php
  namespace Migrations;
  use Core\Migration;

  class Migration1561715872 extends Migration {
    public function up() {
      $table = "sa_criterion_evaluation";
      $this->createTable($table);
      $this->addColumn($table, 'area_id','int');
      $this->addColumn($table, 'area_padrao_id','int');
      $this->addColumn($table, 'name','varchar',['size'=>150]);
      $this->addColumn($table, 'description','text');
      $this->addColumn($table, 'control','int');
      $this->addColumn($table, 'status','varchar',['size'=>10]);
      $this->addSoftDelete($table);
      $this->addTimeStamps($table);

      $this->addForeignKey($table, 'area_id', 'sa_area', 'id');
      $this->addForeignKey($table, 'area_padrao_id', 'sa_area_padrao', 'id');
    }
  }
  