<?php
namespace Migrations;
use Core\Migration;

class Migration1549770647 extends Migration {
  public function up() {
    $table = "users";
    $this->createTable($table);
    $this->addColumn($table,'username','varchar',['size'=>200]);
    $this->addColumn($table,'user_email','varchar',['size'=>200]);
    $this->addColumn($table,'user_password','varchar',['size'=>200]);
    $this->addColumn($table,'fname','varchar',['size'=>200]);
    $this->addColumn($table,'lname','varchar',['size'=>200]);
    $this->addColumn($table,'user_type','varchar',['size'=>10]);
    $this->addColumn($table,'user_status','varchar',['size'=>15]);
    $this->addColumn($table,'cargo_id','int');
    $this->addColumn($table,'categoria_id','int');
    $this->addColumn($table,'country_id','int');
    $this->addColumn($table,'province_id','int');
    $this->addColumn($table,'district_id','int');
    $this->addColumn($table,'place_affection_id','int');
    $this->addColumn($table,'bairro_id','int');
    $this->addColumn($table,'instance_id','int');
    $this->addColumn($table,'acl','text');
    $this->addSoftDelete($table);
    $this->addTimeStamps($table);

    $table = "user_sessions";
    $this->createTable($table);
    $this->addColumn($table,'user_id','int');
    $this->addColumn($table,'session','varchar',['size'=>255]);
    $this->addColumn($table,'user_agent','varchar',['size'=>255]);
    $this->addSoftDelete($table);
    $this->addTimeStamps($table);
    $this->addIndex($table,'user_id');
    $this->addIndex($table,'session');
  }
}
