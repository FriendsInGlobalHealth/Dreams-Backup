<?php
  namespace Migrations;
  use Core\Migration;

  class Migration1562579515 extends Migration {
    public function up() {
      $table = "option_criterion_evaluation"
    }
  }
  