<?php
  namespace Migrations;
  use Core\Migration;

  class Migration1561805508 extends Migration {
    public function up() {
      $table = "sa_evaluation";
      $this->createTable($table);
      $this->addColumn($table, 'comment','varchar',['size'=>150]);
      $this->addColumn($table, 'status_yes','varchar',['size'=>3]);
      $this->addColumn($table, 'criterion_evaluation_id','int');
      $this->addColumn($table, 'means_verification_id','int');
      $this->addColumn($table, 'sanitary_unit_id','int');
      $this->addColumn($table, 'district_id','int');
      $this->addColumn($table, 'date','date');
      $this->addColumn($table, 'user_id','int');
      $this->addColumn($table, 'team_medition','text');
      $this->addColumn($table, 'evaluation_type_id','text');
      $this->addColumn($table, 'status','varchar',['size'=>10]);
      $this->addSoftDelete($table);
      $this->addTimeStamps($table);
      
      $this->addForeignKey($table, 'criterion_evaluation_id', 'sa_criterion_evaluation', 'id');
      $this->addForeignKey($table, 'means_verification_id', 'sa_means_verification', 'id');
      $this->addForeignKey($table, 'evaluation_type_id', 'sa_evaluation_type_id', 'id');
      $this->addForeignKey($table, 'sanitary_unit_id', 'sa_sanitary_unit', 'id');
      $this->addForeignKey($table, 'district_id', 'sa_district', 'id');
      $this->addForeignKey($table, 'user_id', 'users', 'id');
    }
  }
  