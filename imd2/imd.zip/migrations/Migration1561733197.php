<?php
  namespace Migrations;
  use Core\Migration;

  class Migration1561733197 extends Migration {
    public function up() {
      $table = "sa_category";
      $this->createTable($table);
      $this->addColumn($table, 'name','varchar',['size'=>150]);
      $this->addColumn($table, 'status','varchar',['size'=>10]);
      $this->addSoftDelete($table);
      $this->addTimeStamps($table);
    }
  }
  