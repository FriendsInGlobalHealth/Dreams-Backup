<?php
  namespace Migrations;
  use Core\Migration;

  class Migration1561720082 extends Migration {
    public function up() {
      $table = "sa_service";
      $this->createTable($table);
      $this->addColumn($table, 'name','varchar',['size'=>150]);
      $this->addColumn($table, 'status','varchar',['size'=>10]);
      $this->addSoftDelete($table);
      $this->addTimeStamps($table);
    }
  }
  