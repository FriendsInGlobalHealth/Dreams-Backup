<?php
  namespace Migrations;
  use Core\Migration;

  class Migration1561802876 extends Migration {
    public function up() {
      $table = "sa_means_verification";
      $this->createTable($table);
      $this->addColumn($table, 'name','varchar',['size'=>200]);
      $this->addColumn($table, 'status','varchar',['size'=>10]);
      $this->addSoftDelete($table);
      $this->addTimeStamps($table);
    }
  }
  