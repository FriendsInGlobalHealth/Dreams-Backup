<?php
  namespace Migrations;
  use Core\Migration;

  class Migration1561716378 extends Migration {
    public function up() {
      $table = "sa_area";
      $this->createTable($table);
      $this->addColumn($table, 'name','varchar',['size'=>150]);
      $this->addColumn($table, 'status','varchar',['size'=>10]);
      $this->addSoftDelete($table);
      $this->addTimeStamps($table);
    }
  }
  