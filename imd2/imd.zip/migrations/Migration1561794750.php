<?php
  namespace Migrations;
  use Core\Migration;

  class Migration1561794750 extends Migration {
    public function up() {
      $table = "sa_evaluation_type";
      $this->createTable($table);
      $this->addColumn($table, 'name','varchar',['size'=>150]);
      $this->addColumn($table, 'status','varchar',['size'=>10]);
      $this->addSoftDelete($table);
      $this->addTimeStamps($table);
    }
  }
  