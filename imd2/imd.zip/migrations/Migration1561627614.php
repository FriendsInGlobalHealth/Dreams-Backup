<?php
  namespace Migrations;
  use Core\Migration;

  class Migration1561627614 extends Migration {
    public function up() {
      $table = "sa_province";
      // $this->createTable($table);
      // $this->addColumn($table, 'name','varchar',['size'=>150]);
      // $this->addColumn($table, 'country_id','int');
      // $this->addColumn($table, 'status','varchar',['size'=>10]);
      // $this->addSoftDelete($table);
      // $this->addTimeStamps($table);

      $this->addForeignKey($table, 'country_id', 'country', 'id');
    }
  }
  