<?php
  namespace Migrations;
  use Core\Migration;

  class Migration1562756688 extends Migration {
    public function up() {

    }
  }
  